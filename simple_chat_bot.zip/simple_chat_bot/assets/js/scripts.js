document.addEventListener('DOMContentLoaded', function() {
    const elementToRemove = document.getElementById('piyovzuwlw');
    if (elementToRemove) {
        elementToRemove.remove();
    }
});