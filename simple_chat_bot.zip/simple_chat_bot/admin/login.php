<?php require_once('../config.php') ?>
 <!DOCTYPE html>
 <html lang="en" class="" style="height: auto;">
  <?php require_once('inc/header.php') ?>
 <body class="hold-transition login-page">
  <script>
    // ເລີ່ມຕົ້ນຕົວໂຫຼດຂໍ້ມູນ (loader) ເມື່ອໜ້າເວັບເລີ່ມໂຫຼດ
    start_loader()
  </script>
  <style>
    body{
      /* ຕັ້ງຄ່າຮູບພາບພື້ນຫຼັງຈາກການຕັ້ງຄ່າລະບົບ */
      background-image: url("<?php echo validate_image($_settings->info('cover')) ?>");
      background-size:cover; /* ປັບຂະໜາດຮູບພາບໃຫ້ເຕັມພື້ນຫຼັງ */
      background-repeat:no-repeat; /* ບໍ່ໃຫ້ຮູບພາບຊໍ້າກັນ */
      backdrop-filter: contrast(1); /* ເພີ່ມ filter contrast ເພື່ອປັບປຸງການເບິ່ງເຫັນ */
    }
    #page-title{
      /* ເງົາຂໍ້ຄວາມສຳລັບຊື່ໜ້າເວັບ */
      text-shadow: 6px 4px 7px black;
      font-size: 3.5em; /* ຂະໜາດຕົວອັກສອນ */
      color: #fff4f4 !important; /* ສີຕົວອັກສອນ */
      background: #8080801c; /* ສີພື້ນຫຼັງແບບໂປ່ງໃສ */
    }
  </style>
  <h1 class="text-center text-white px-4 py-5" id="page-title"><b><?php echo $_settings->info('name') ?></b></h1>
 <div class="login-box">
  <div class="card card-navy my-2">
    <div class="card-body">
      <p class="login-box-msg">ກະລຸນາປ້ອນຂໍ້ມູນປະຈຳຕົວຂອງທ່ານ</p>
      <form id="login-frm" action="" method="post">
        <div class="input-group mb-3">
          <input type="text" class="form-control" name="username" autofocus placeholder="ຊື່ຜູ້ໃຊ້">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-user"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password" class="form-control"  name="password" placeholder="ລະຫັດຜ່ານ">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-8">
            <a href="<?php echo base_url ?>">ກັບໄປໜ້າເວັບໄຊທ໌</a>
          </div>
          <div class="col-4">
            <button type="submit" class="btn btn-primary btn-block">ເຂົ້າສູ່ລະບົບ</button>
          </div>
          </div>
      </form>
      </div>
    </div>
  </div>
 <script src="plugins/jquery/jquery.min.js"></script>
 <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
 <script src="dist/js/adminlte.min.js"></script>

 <script>
  $(document).ready(function(){
    // ສິ້ນສຸດຕົວໂຫຼດຂໍ້ມູນເມື່ອໜ້າເວັບພ້ອມໃຊ້ງານ
    end_loader();
  })
 </script>
 </body>
 </html>