<?php if($_settings->chk_flashdata('success')): ?>
 <script>
    // ສະແດງຂໍ້ຄວາມແຈ້ງເຕືອນສຳເລັດ (toast notification) ຖ້າມີ flashdata ປະເພດ 'success'.
    alert_toast("<?php echo $_settings->flashdata('success') ?>",'success')
 </script>
 <?php endif;?>
 <style>
    /* ແບບສີສຳລັບຮູບພາບຜະລິດຕະພັນ (ບໍ່ໄດ້ຖືກໃຊ້ໃນລະຫັດນີ້ໂດຍກົງ, ອາດຈະເປັນແບບສີທີ່ສືບທອດມາຈາກໂຄງສ້າງອື່ນ). */
    .prod-img{
        width: 5em;
        max-height: 8em;
        object-fit:scale-down;
        object-position:center center;
    }
 </style>
 <div class="card card-outline rounded-0 card-navy">
    <div class="card-header">
        <h3 class="card-title">ລາຍຊື່ການຕອບສະໜອງ</h3>
        <div class="card-tools">
            <a href="./?page=responses/manage_response" id="create_new" class="btn btn-flat btn-primary"><span class="fas fa-plus"></span>  ສ້າງໃໝ່</a>
        </div>
    </div>
    <div class="card-body">
        <div class="container-fluid">
            <table class="table table-hover table-striped table-bordered" id="list">
                <colgroup>
                    <col width="5%">
                    <col width="15%">
                    <col width="25%">
                    <col width="25%">
                    <col width="15%">
                    <col width="15%">
                </colgroup>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>ວັນທີ່ສ້າງ</th>
                        <th>ການຕອບສະໜອງ</th>
                        <th>ຄຳສັບຫຼັກ</th>
                        <th>ສະຖານະ</th>
                        <th>ການກະທຳ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $i = 1; // ຕົວນັບສຳລັບລຳດັບ.
                        // ຄຳສັ່ງ SQL ເພື່ອດຶງຂໍ້ມູນການຕອບສະໜອງທັງໝົດ, ຈັດຮຽງຕາມວັນທີ່ສ້າງຫຼ້າສຸດ.
                        $qry = $conn->query("SELECT * from `response_list`  order by unix_timestamp(`date_created`) desc ");
                        while($row = $qry->fetch_assoc()):
                            // ດຶງຄຳສັບຫຼັກທີ່ກ່ຽວຂ້ອງກັບການຕອບສະໜອງນີ້.
                            $kw_qry = $conn->query("SELECT * FROM keyword_list where response_id = '{$row['id']}'");
                            // ແຍກຄໍລຳ 'keyword' ອອກມາເປັນ Array.
                            $kws = array_column($kw_qry->fetch_all(MYSQLI_ASSOC), 'keyword');
                            if(count($kws)){
                                $kws = implode(", ",$kws); // ລວມຄຳສັບຫຼັກເຂົ້າເປັນ String ແຍກດ້ວຍເຄື່ອງໝາຍຈຸດ.
                            }else{
                                $kws = "N/A"; // ຖ້າບໍ່ມີຄຳສັບຫຼັກ.
                            }
                    ?>
                        <tr>
                            <td class="text-center"><?php echo $i++; ?></td>
                            <td><?php echo date("Y-m-d H:i",strtotime($row['date_created'])) ?></td>
                            <td><p class="truncate-1 m-0"><?php echo strip_tags($row['response']) ?></p></td>
                            <td><?= $kws ?></td>
                            <td class="text-center">
                                <?php if($row['status'] == 1): ?>
                                    <span class="badge badge-success px-3 rounded-pill">ເປີດໃຊ້ງານ</span>
                                <?php else: ?>
                                    <span class="badge badge-danger px-3 rounded-pill">ປິດໃຊ້ງານ</span>
                                <?php endif; ?>
                            </td>
                            <td align="center">
                                 <button type="button" class="btn btn-flat p-1 btn-default btn-sm dropdown-toggle dropdown-icon" data-toggle="dropdown">
                                        ການກະທຳ
                                    <span class="sr-only">Toggle Dropdown</span>
                                  </button>
                                  <div class="dropdown-menu" role="menu">
                                    <a class="dropdown-item view_data" href="./?page=responses/view_response&id=<?php echo $row['id'] ?>"><span class="fa fa-eye text-dark"></span> ເບິ່ງ</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item edit_data" href="./?page=responses/manage_response&id=<?php echo $row['id'] ?>"><span class="fa fa-edit text-primary"></span> ແກ້ໄຂ</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item delete_data" href="javascript:void(0)" data-id="<?php echo $row['id'] ?>"><span class="fa fa-trash text-danger"></span> ລຶບ</a>
                                  </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
 </div>
 <script>
    $(document).ready(function(){
        // ເມື່ອກົດປຸ່ມ "ລຶບ" (class `delete_data`), ຈະສະແດງຂໍ້ຄວາມຢືນຢັນ.
        $('.delete_data').click(function(){
            _conf("ທ່ານແນ່ໃຈບໍວ່າຕ້ອງການລຶບການຕອບສະໜອງນີ້ຢ່າງຖາວອນ?","delete_response",[$(this).attr('data-id')])
        })
        // ເປີດໃຊ້ງານ DataTables ສຳລັບຕາຕະລາງ `list`.
        $('.table').dataTable({
            columnDefs: [
                    { orderable: false, targets: [6] } // ປິດການຈັດຮຽງສຳລັບຄໍລຳການກະທຳ.
            ],
            order:[0,'asc'] // ຈັດຮຽງຕາມຄໍລຳທຳອິດ (ລຳດັບ) ແບບຂຶ້ນ.
        });
        // ເພີ່ມ class CSS ໃສ່ cell ຕາຕະລາງ.
        $('.dataTable td,.dataTable th').addClass('py-1 px-2 align-middle')
    })

    // ຟັງຊັນ `delete_response` ເພື່ອລຶບການຕອບສະໜອງຜ່ານ AJAX.
    function delete_response($id){
        start_loader(); // ເລີ່ມຕົ້ນ loader.
        $.ajax({
            url:_base_url_+"classes/Master.php?f=delete_response", // URL ຂອງ script ທີ່ຈະຈັດການການລຶບ.
            method:"POST", // ວິທີການສົ່ງຂໍ້ມູນ.
            data:{id: $id}, // ສົ່ງ ID ຂອງການຕອບສະໜອງທີ່ຕ້ອງການລຶບ.
            dataType:"json", // ຄາດຫວັງຂໍ້ມູນກັບຄືນເປັນ JSON.
            error:err=>{
                console.log(err)
                alert_toast("ເກີດຂໍ້ຜິດພາດ.","error"); // ສະແດງຂໍ້ຄວາມຜິດພາດ.
                end_loader(); // ສິ້ນສຸດ loader.
            },
            success:function(resp){
                if(typeof resp== 'object' && resp.status == 'success'){
                    location.reload(); // ໂຫຼດໜ້າຄືນໃໝ່ຖ້າການລຶບສຳເລັດ.
                }else{
                    alert_toast("ເກີດຂໍ້ຜິດພາດ.","error"); // ສະແດງຂໍ້ຄວາມຜິດພາດ.
                    end_loader(); // ສິ້ນສຸດ loader.
                }
            }
        })
    }
 </script>