<?php
 // ກວດສອບວ່າ parameter 'id' ຖືກຕັ້ງຄ່າໃນ URL ແລະມີຄ່າຫຼາຍກວ່າ 0 ບໍ່.
 // ຖ້າຖືກຕັ້ງ, ໝາຍຄວາມວ່າກຳລັງແກ້ໄຂຂໍ້ມູນການຕອບສະໜອງທີ່ມີຢູ່ແລ້ວ.
 if(isset($_GET['id']) && $_GET['id'] > 0){
    // ດຶງຂໍ້ມູນການຕອບສະໜອງຈາກຖານຂໍ້ມູນໂດຍໃຊ້ ID ທີ່ໄດ້ຮັບຈາກ URL.
    $qry = $conn->query("SELECT * from `response_list` where id = '{$_GET['id']}' ");
    // ຖ້າພົບຂໍ້ມູນ, ວົນລູບຜ່ານແຖວຂໍ້ມູນທີ່ດຶງມາ ແລະສ້າງຕົວແປທີ່ມີຊື່ຕາມຊື່ຄໍລຳ.
    if($qry->num_rows > 0){
        foreach($qry->fetch_assoc() as $k => $v){
            $$k=$v; // ຕົວຢ່າງ: ຖ້າ $k ເປັນ 'response', ຈະສ້າງ $response = $v.
        }
    }
 }
 ?>
 <div class="content px-2 py-5 bg-gradient-primary">
    <h4 class="my-3"><b><?= !isset($id) ? "ສ້າງການຕອບສະໜອງໃໝ່" : "ອັບເດດລາຍລະອຽດການຕອບສະໜອງ" ?></b></h4>
 </div>
 <div class="row mt-n5 justify-content-center">
    <div class="col-lg-8 col-md-10 col-sm-12 col-xs-12">
        <div class="card rounded-0 shadow">
            <div class="card-body">
                <div class="container-fluid">
                    <form action="" id="response-form">
                        <input type="hidden" name ="id" value="<?php echo isset($id) ? $id : '' ?>">
                        <div class="form-group">
                            <label for="response" class="control-label">ລາຍລະອຽດ</label>
                            <textarea type="text" name="response" id="response" class="form-control form-control-sm rounded-0" required><?php echo isset($response) ? $response : ''; ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="status" class="control-label">ສະຖານະ</label>
                            <select name="status" id="status" class="form-control form-control-sm rounded-0" required>
                                <option value="1" <?php echo isset($status) && $status == 1 ? 'selected' : '' ?>>ເປີດໃຊ້ງານ</option>
                                <option value="0" <?php echo isset($status) && $status == 0 ? 'selected' : '' ?>>ປິດໃຊ້ງານ</option>
                            </select>
                        </div>
                        <div class="clear-fix mt-3"></div>
                        <div class="row bg-gradient-primary">
                            <div class="col-11 border m-0 px-2 py-1">ຄຳສັບຫຼັກ</div>
                            <div class="col-1 border m-0 px-2 py-1">ການກະທຳ</div>
                        </div>
                        <div id="keyword-list" class="mb-3">
                            <?php if(isset($id)): // ຖ້າມີ ID (ກຳລັງແກ້ໄຂ), ໃຫ້ໂຫຼດຄຳສັບຫຼັກທີ່ມີຢູ່ແລ້ວ. ?>
                            <?php
                            // ດຶງຄຳສັບຫຼັກທັງໝົດທີ່ກ່ຽວຂ້ອງກັບການຕອບສະໜອງນີ້.
                            $kw_qry = $conn->query("SELECT * FROM `keyword_list` where response_id = '{$id}'");
                            while($row = $kw_qry->fetch_assoc()):
                            ?>
                            <div class="row bg-gradient-light align-items-center kw-item" style="height:4.5em">
                                <div class="col-11 border m-0 px-2 py-1 h-100">
                                    <textarea name="keyword[]" cols="30" rows="2" class="form-control form-control-sm rounded-0" required="required" style="resize:none"><?= $row['keyword'] ?></textarea>
                                </div>
                                <div class="col-1 border m-0 px-2 py-1 text-center align-items-center h-100 justify-content-center d-flex">
                                    <div class="col-auto">
                                        <button class="btn-outline-danger btn btn-sm rounded-0 rem-item" type="button"><i class="fa fa-times"></i></button>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                            <?php else: // ຖ້າບໍ່ມີ ID (ກຳລັງສ້າງໃໝ່), ໃຫ້ສະແດງຊ່ອງປ້ອນຄຳສັບຫຼັກເປົ່າ. ?>
                            <div class="row bg-gradient-light align-items-center kw-item" style="height:4.5em">
                                <div class="col-11 border m-0 px-2 py-1 h-100">
                                    <textarea name="keyword[]" cols="30" rows="2" class="form-control form-control-sm rounded-0" required="required" style="resize:none"></textarea>
                                </div>
                                <div class="col-1 border m-0 px-2 py-1 text-center align-items-center h-100 justify-content-center d-flex">
                                    <div class="col-auto">
                                        <button class="btn-outline-danger btn btn-sm rounded-0 rem-item" type="button"><i class="fa fa-times"></i></button>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="text-right">
                            <button class="btn btn-primary btn-sm rounded-0" type="button" id="add_kw_item"><i class="far fa-plus-square mb-n2 mr-1"></i>ເພີ່ມຄຳສັບຫຼັກ</button>
                        </div>
                        <div class="clear-fix mt-3"></div>
                        <div class="row bg-gradient-primary">
                            <div class="col-11 border m-0 px-2 py-1">ຄຳແນະນຳ</div>
                            <div class="col-1 border m-0 px-2 py-1">ການກະທຳ</div>
                        </div>
                        <div id="suggestion-list" class="mb-3">
                            <?php if(isset($id)): // ຖ້າມີ ID (ກຳລັງແກ້ໄຂ), ໃຫ້ໂຫຼດຄຳແນະນຳທີ່ມີຢູ່ແລ້ວ. ?>
                            <?php
                            // ດຶງຄຳແນະນຳທັງໝົດທີ່ກ່ຽວຂ້ອງກັບການຕອບສະໜອງນີ້.
                            $sg_qry = $conn->query("SELECT * FROM `suggestion_list` where response_id = '{$id}'");
                            while($row = $sg_qry->fetch_assoc()):
                            ?>
                            <div class="row bg-gradient-light align-items-center sg-item" style="height:4.5em">
                                <div class="col-11 border m-0 px-2 py-1 h-100">
                                    <textarea name="suggestion[]" cols="30" rows="2" class="form-control form-control-sm rounded-0" style="resize:none"><?= $row['suggestion'] ?></textarea>
                                </div>
                                <div class="col-1 border m-0 px-2 py-1 text-center align-items-center h-100 justify-content-center d-flex">
                                    <div class="col-auto">
                                        <button class="btn-outline-danger btn btn-sm rounded-0 rem-item" type="button"><i class="fa fa-times"></i></small></button>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                            <?php endif; ?>
                            <div class="row bg-gradient-light align-items-center sg-item" style="height:4.5em">
                                <div class="col-11 border m-0 px-2 py-1 h-100">
                                    <textarea name="suggestion[]" cols="30" rows="2" class="form-control form-control-sm rounded-0" style="resize:none"></textarea>
                                </div>
                                <div class="col-1 border m-0 px-2 py-1 text-center align-items-center h-100 justify-content-center d-flex">
                                    <div class="col-auto">
                                        <button class="btn-outline-danger btn btn-sm rounded-0 rem-item" type="button"><i class="fa fa-times"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="text-right">
                            <button class="btn btn-primary btn-sm rounded-0" type="button" id="add_suggestion_item"><i class="far fa-plus-square mb-n2 mr-1"></i>ເພີ່ມຄຳແນະນຳ</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="card-footer py-1 text-center">
                <button class="btn btn-sm btn-primary bg-gradient-primary rounded-0" form="response-form"><i class="fa fa-save"></i> ບັນທຶກ</button>
                <a class="btn btn-sm btn-light bg-gradient-light border rounded-0" href="./?page=responses"><i class="fa fa-angle-left"></i> ຍົກເລີກ</a>
            </div>
        </div>
    </div>
 </div>
 <script>
    $(document).ready(function(){
        // ການຈັດການການລຶບ Keyword Item.
        // ຖ້າມີຫຼາຍກວ່າໜຶ່ງ Item, ໃຫ້ລຶບ Item ທີ່ຖືກເລືອກ.
        // ຖ້າມີພຽງແຕ່ໜຶ່ງ Item, ໃຫ້ລຶບຄ່າໃນ Textarea ແລະ Focus ໃສ່ມັນ.
        $('#keyword-list .kw-item').find('.rem-item').click(function(){
            if($('#keyword-list .kw-item').length > 1){
                $(this).closest('.kw-item').remove()
            }else{
                $(this).closest('.kw-item').find('[name="keyword[]"]').val('').focus()
            }
        })
        // ການຈັດການການລຶບ Suggestion Item (ຄ້າຍຄືກັບ Keyword Item).
        $('#suggestion-list .sg-item').find('.rem-item').click(function(){
            if($('#suggestion-list .sg-item').length > 1){
                $(this).closest('.sg-item').remove()
            }else{
                $(this).closest('.sg-item').find('[name="suggestion[]"]').val('').focus()
            }
        })

        // ເພີ່ມ Keyword Item ໃໝ່.
        $('#add_kw_item').click(function(){
            var item = $('#keyword-list .kw-item:nth-child(1)').clone() // Clone Item ທຳອິດ.
            item.find('[name="keyword[]"]').val('').removeClass('border-danger') // ລຶບຄ່າແລະ Class border-danger ອອກ.
            $('#keyword-list').append(item) // ເພີ່ມ Item ໃໝ່ເຂົ້າໄປ.
            item.find('[name="keyword[]"]').focus() // Focus ໃສ່ Textarea ໃໝ່.
            item.find('.rem-item').click(function(){ // ກຳນົດ Event Handler ສຳລັບປຸ່ມລຶບຂອງ Item ໃໝ່.
                if($('#keyword-list .kw-item').length > 1){
                    item.remove()
                }else{
                    item.find('[name="keyword[]"]').val('').focus()
                }
            })
        })
        // ເພີ່ມ Suggestion Item ໃໝ່ (ຄ້າຍຄືກັບ Keyword Item).
        $('#add_suggestion_item').click(function(){
            var item = $('#suggestion-list .sg-item:nth-child(1)').clone()
            item.find('[name="suggestion[]"]').val('').removeClass('border-danger')
            $('#suggestion-list').append(item)
            item.find('[name="suggestion[]"]').focus()
            item.find('.rem-item').click(function(){
                if($('#suggestion-list .sg-item').length > 1){
                    item.remove()
                }else{
                    item.find('[name="suggestion[]"]').val('').focus()
                }
            })
        })

        // ເປີດໃຊ້ງານ Summernote Editor ສຳລັບ Textarea Response.
        $('#response').summernote({
            height: "15em", // ກຳນົດຄວາມສູງ.
            toolbar: [ // ກຳນົດ Toolbar ທີ່ສະແດງ.
                [ 'font', [ 'bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript', 'clear'] ],
                [ 'fontname', [ 'fontname' ] ],
                [ 'fontsize', [ 'fontsize' ] ],
                [ 'color', [ 'color' ] ],
                [ 'para', [ 'ol', 'ul', 'paragraph', 'height' ] ],
                [ 'view', [ 'undo', 'redo' ] ]
            ]
        })

        // ການຈັດການການ Submit ຟອມ `response-form` ດ້ວຍ AJAX.
        $('#response-form').submit(function(e){
            e.preventDefault(); // ຢຸດການ Submit ຟອມແບບປົກກະຕິ.
            var _this = $(this)
             $('.err-msg').remove(); // ລຶບຂໍ້ຄວາມຜິດພາດທີ່ເຄີຍມີອອກ.
             $('.border-danger').removeClass('border-danger') // ລຶບ Class border-danger ອອກ.
             var el = $('<div>') // ສ້າງ Element div ສຳລັບຂໍ້ຄວາມຜິດພາດ.
                 el.addClass("alert alert-danger err-msg")
                 el.hide()
            start_loader(); // ເລີ່ມຕົ້ນ loader.
            $.ajax({
                url:_base_url_+"classes/Master.php?f=save_response", // URL ຂອງ script ທີ່ຈະຈັດການການບັນທຶກ/ອັບເດດການຕອບສະໜອງ.
                data: new FormData($(this)[0]), // ຂໍ້ມູນຟອມ.
                cache: false,
                contentType: false,
                processData: false,
                method: 'POST', // ວິທີການສົ່ງຂໍ້ມູນ.
                type: 'POST',
                dataType: 'json', // ຄາດຫວັງຂໍ້ມູນກັບຄືນເປັນ JSON.
                error:err=>{ // ຈັດການຂໍ້ຜິດພາດຂອງ AJAX.
                    console.log(err)
                    alert_toast("ເກີດຂໍ້ຜິດພາດ",'error');
                    end_loader();
                },
                success:function(resp){ // ເມື່ອ AJAX ສຳເລັດ.
                    if(typeof resp =='object' && resp.status == 'success'){
                        // ຖ້າສຳເລັດ, ນຳຜູ້ໃຊ້ໄປໜ້າລາຍລະອຽດຂອງການຕອບສະໜອງທີ່ຖືກບັນທຶກ.
                        location.href = './?page=responses/view_response&id='+resp.rid
                    }else if(resp.status == 'failed' && !!resp.msg){
                        // ຖ້າລົ້ມເຫຼວ ແລະມີຂໍ້ຄວາມ, ສະແດງຂໍ້ຄວາມນັ້ນ.
                        if('kw_index' in resp){ // ຖ້າມີ kw_index, ໝາຍຄວາມວ່າຄຳສັບຫຼັກຊໍ້າກັນ.
                            $('[name="keyword[]"]').eq(resp.kw_index).addClass('border-danger').focus() // ເນັ້ນຊ່ອງທີ່ມີບັນຫາ.
                            $('[name="keyword[]"]').eq(resp.kw_index)[0].setCustomValidity(resp.msg) // ຕັ້ງຂໍ້ຄວາມຜິດພາດ.
                            $('[name="keyword[]"]').eq(resp.kw_index)[0].reportValidity() // ສະແດງຂໍ້ຄວາມຜິດພາດ.
                            $('[name="keyword[]"]').eq(resp.kw_index).on('input', function(){ // ເມື່ອມີການປ່ຽນແປງ, ລຶບຂໍ້ຄວາມຜິດພາດ.
                                $(this).removeClass('border-danger')
                                $(this)[0].setCustomValidity("")
                            })
                        }else{
                            el.text(resp.msg) // ສະແດງຂໍ້ຄວາມຜິດພາດທົ່ວໄປ.
                            _this.prepend(el)
                            el.show('slow')
                            $("html, body,.modal").scrollTop(0); // ເລື່ອນໜ້າຂຶ້ນເທິງ.
                        }
                    }else{
                        alert_toast("ເກີດຂໍ້ຜິດພາດ",'error');
                    }
                    end_loader() // ສິ້ນສຸດ loader.
                }
            })
        })

    })
 </script>