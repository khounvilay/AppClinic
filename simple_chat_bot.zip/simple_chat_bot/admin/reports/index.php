<?php if($_settings->chk_flashdata('success')): ?>
 <script>
    // ສະແດງຂໍ້ຄວາມແຈ້ງເຕືອນສຳເລັດ (toast notification) ຖ້າມີ flashdata ປະເພດ 'success'.
    alert_toast("<?php echo $_settings->flashdata('success') ?>",'success')
 </script>
 <?php endif;?>
 <?php $date = isset($_GET['date']) ? $_GET['date'] : date("Y-m-d"); ?>
 <div class="card card-outline rounded-0 card-navy">
    <div class="card-header">
        <h3 class="card-title">ລາຍງານ</h3>
        <div class="card-tools">
            <button class="btn btn-light btn-sm bg-gradient-light rounded-0 border" type="button" id="print"><i class="fa fa-print"></i> ພິມ</button>
        </div>
    </div>
    <div class="card-body">
        <div class="container-fluid" id="printout">
            <table class="table table-hover table-striped table-bordered">
                <colgroup>
                    <col width="10%">
                    <col width="70%">
                    <col width="20%">
                </colgroup>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>ການຕອບສະໜອງ</th>
                        <th>ຈໍານວນຄັ້ງທີ່ຖືກດຶງ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $total = 0; // ຕົວແປສຳລັບຄຳນວນຈຳນວນລວມ (ບໍ່ໄດ້ຖືກໃຊ້ໃນປັດຈຸບັນ).
                    $i = 1; // ຕົວນັບສຳລັບລຳດັບ.
                    // ດຶງຂໍ້ມູນການຕອບສະໜອງ ແລະ ຈຳນວນຄັ້ງທີ່ຖືກດຶງຈາກ `keyword_fetched`
                    // ຈັດຮຽງຕາມຈຳນວນຄັ້ງທີ່ຖືກດຶງຫຼາຍທີ່ສຸດລົງໜ້ອຍທີ່ສຸດ.
                    $qry = $conn->query("SELECT *, COALESCE((SELECT count(response_id) FROM `keyword_fetched` where response_id = response_list.id), 0) as `Workspaceed` FROM `response_list` order by COALESCE((SELECT count(response_id) FROM `keyword_fetched` where response_id = response_list.id), 0) desc");
                    while($row = $qry->fetch_assoc()):
                    ?>
                        <tr>
                            <td class="text-center"><?php echo $i++; ?></td>
                            <td><p class="m-0"><?= strip_tags($row['response']) ?></p></td>
                            <td class='text-right'><?= format_num($row['fetched']) ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
 </div>
 <noscript id="print-header">
    <div>
    <div class="d-flex w-100">
        <div class="col-2 text-center">
            <img style="height:.8in;width:.8in!important;object-fit:cover;object-position:center center" src="<?= validate_image($_settings->info('logo')) ?>" alt="" class="w-100 img-thumbnail rounded-circle">
        </div>
        <div class="col-8 text-center">
            <div style="line-height:1em">
                <h4 class="text-center mb-0"><?= $_settings->info('name') ?></h4>
                <h3 class="text-center mb-0"><b>ລາຍງານການຕອບສະໜອງ</b></h3>
            </div>
        </div>
    </div>
    <hr>
    </div>
 </noscript>
 <script>
    $(document).ready(function(){
        // ເມື່ອກົດປຸ່ມ 'ພິມ', ຈະເປີດໜ້າຕ່າງໃໝ່ສຳລັບການພິມ.
        $('#print').click(function(){
            var h = $('head').clone() // ສຳເນົາສ່ວນ <head> ຂອງໜ້າປັດຈຸບັນ.
            var ph = $($('noscript#print-header').html()).clone() // ສຳເນົາ Header ສຳລັບການພິມ.
            var p = $('#printout').clone() // ສຳເນົາເນື້ອໃນຕາຕະລາງທີ່ຈະພິມ.
            h.find('title').text('ລາຍງານການຕອບສະໜອງ - ມຸມມອງການພິມ') // ປ່ຽນ Title ຂອງໜ້າພິມ.

            start_loader() // ເລີ່ມຕົ້ນ loader.
            // ເປີດໜ້າຕ່າງໃໝ່ສຳລັບການພິມ, ກຳນົດຂະໜາດ ແລະ ຕຳແໜ່ງ.
            var nw = window.open("", "_blank", "width="+($(window).width() * .8)+", height="+($(window).height() * .8)+", left="+($(window).width() * .1)+", top="+($(window).height() * .1))
                     nw.document.querySelector('head').innerHTML = h.html() // ເພີ່ມ <head> ທີ່ສຳເນົາໃສ່ໜ້າພິມ.
                     nw.document.querySelector('body').innerHTML = ph.html() // ເພີ່ມ Header ໃສ່ Body ຂອງໜ້າພິມ.
                     nw.document.querySelector('body').innerHTML += p[0].outerHTML // ເພີ່ມເນື້ອໃນຕາຕະລາງໃສ່ Body.
                     nw.document.close() // ປິດການຂຽນເອກະສານ.
                     setTimeout(() => {
                         nw.print() // ເປີດໜ້າຕ່າງພິມ.
                         setTimeout(() => {
                             nw.close() // ປິດໜ້າຕ່າງພິມຫຼັງຈາກພິມ.
                             end_loader() // ສິ້ນສຸດ loader.
                         }, 300);
                     }, 300);
        })
    })

 </script>