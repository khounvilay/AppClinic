<?php if($_settings->chk_flashdata('success')): ?>
 <script>
    // ສະແດງຂໍ້ຄວາມແຈ້ງເຕືອນສຳເລັດ (toast notification) ຖ້າມີ flashdata ປະເພດ 'success'.
    alert_toast("<?php echo $_settings->flashdata('success') ?>",'success')
 </script>
 <?php endif;?>
 <style>
    /* ແບບສີສຳລັບຮູບ avatar ຂອງຜູ້ໃຊ້ໃນຕາຕະລາງ. */
    .user-avatar{
        width:3rem; /* ກຳນົດຄວາມກວ້າງ */
        height:3rem; /* ກຳນົດຄວາມສູງ */
        object-fit:scale-down; /* ປັບຂະໜາດຮູບໃຫ້ພໍດີພື້ນທີ່ໂດຍບໍ່ມີການຕັດຮູບ */
        object-position:center center; /* ຈັດຕຳແໜ່ງຮູບໃຫ້ຢູ່ກາງ */
    }
 </style>
 <div class="card card-outline rounded-0 card-navy">
    <div class="card-header">
        <h3 class="card-title">ລາຍຊື່ຜູ້ໃຊ້</h3>
        <div class="card-tools">
            <a href="./?page=user/manage_user" id="create_new" class="btn btn-flat btn-primary"><span class="fas fa-plus"></span>  ສ້າງໃໝ່</a>
        </div>
    </div>
    <div class="card-body">
        <div class="container-fluid">
            <table class="table table-hover table-striped table-bordered" id="list">
                <colgroup>
                    <col width="5%">
                    <col width="15%">
                    <col width="15%">
                    <col width="25%">
                    <col width="15%">
                    <col width="10%">
                    <col width="15%">
                </colgroup>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>ວັນທີ່ອັບເດດ</th>
                        <th>ຮູບໂປຣໄຟລ໌</th>
                        <th>ຊື່</th>
                        <th>ຊື່ຜູ້ໃຊ້</th>
                        <th>ປະເພດ</th>
                        <th>ການກະທຳ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $i = 1; // ຕົວນັບສຳລັບລຳດັບ.
                        // ຄຳສັ່ງ SQL ເພື່ອດຶງຂໍ້ມູນຜູ້ໃຊ້ທັງໝົດ, ຍົກເວັ້ນຜູ້ໃຊ້ທີ່ເຂົ້າສູ່ລະບົບປັດຈຸບັນ.
                        // ຈັດຮຽງຕາມຊື່.
                        $qry = $conn->query("SELECT *, concat(firstname,' ', lastname) as `name` from `users` where id != '{$_settings->userdata('id')}' order by concat(firstname,' ', lastname) asc ");
                        while($row = $qry->fetch_assoc()): // ວົນລູບຜ່ານແຕ່ລະແຖວຂອງຜົນລັບ.
                    ?>
                        <tr>
                            <td class="text-center"><?php echo $i++; ?></td>
                            <td><?php echo date("Y-m-d H:i",strtotime($row['date_updated'])) ?></td>
                            <td class="text-center">
                                <img src="<?= validate_image($row['avatar']) ?>" alt="" class="img-thumbnail rounded-circle user-avatar">
                            </td>
                            <td><?php echo $row['name'] ?></td>
                            <td><?php echo $row['username'] ?></td>
                            <td class="text-center">
                                <?php if($row['type'] == 1): ?>
                                    ຜູ້ດູແລລະບົບ
                                <?php elseif($row['type'] == 2): ?>
                                    ພະນັກງານ
                                <?php else: ?>
                                    ບໍ່ລະບຸ
                                <?php endif; ?>
                            </td>
                            <td align="center">
                                 <button type="button" class="btn btn-flat p-1 btn-default btn-sm dropdown-toggle dropdown-icon" data-toggle="dropdown">
                                        ການກະທຳ
                                    <span class="sr-only">ສະຫຼັບ Dropdown</span>
                                  </button>
                                  <div class="dropdown-menu" role="menu">
                                    <a class="dropdown-item" href="./?page=user/manage_user&id=<?= $row['id'] ?>"><span class="fa fa-edit text-dark"></span> ແກ້ໄຂ</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item delete_data" href="javascript:void(0)" data-id="<?php echo $row['id'] ?>"><span class="fa fa-trash text-danger"></span> ລຶບ</a>
                                  </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
 </div>
 <script>
    $(document).ready(function(){
        // ເມື່ອກົດປຸ່ມ "ລຶບ" (class `delete_data`), ຈະສະແດງຂໍ້ຄວາມຢືນຢັນ.
        $('.delete_data').click(function(){
            _conf("ທ່ານແນ່ໃຈບໍວ່າຕ້ອງການລຶບຜູ້ໃຊ້ນີ້ຢ່າງຖາວອນ?","delete_user",[$(this).attr('data-id')])
        })
        // ເປີດໃຊ້ງານ DataTables ສຳລັບຕາຕະລາງ `list`.
        $('.table').dataTable({
            columnDefs: [
                    { orderable: false, targets: [6] } // ປິດການຈັດຮຽງສຳລັບຄໍລຳການກະທຳ.
            ],
            order:[0,'asc'] // ຈັດຮຽງຕາມຄໍລຳທຳອິດ (ລຳດັບ) ແບບຂຶ້ນ.
        });
        // ເພີ່ມ class CSS ໃສ່ cell ຕາຕະລາງ.
        $('.dataTable td,.dataTable th').addClass('py-1 px-2 align-middle')
    })

    // ຟັງຊັນ `delete_user` ເພື່ອລຶບຜູ້ໃຊ້ຜ່ານ AJAX.
    function delete_user($id){
        start_loader(); // ເລີ່ມຕົ້ນ loader.
        $.ajax({
            url:_base_url_+"classes/Users.php?f=delete", // URL ຂອງ script ທີ່ຈະຈັດການການລຶບ.
            method:"POST", // ວິທີການສົ່ງຂໍ້ມູນ.
            data:{id: $id}, // ສົ່ງ ID ຂອງຜູ້ໃຊ້ທີ່ຕ້ອງການລຶບ.
            error:err=>{
                console.log(err)
                alert_toast("ເກີດຂໍ້ຜິດພາດ.","error"); // ສະແດງຂໍ້ຄວາມຜິດພາດ.
                end_loader(); // ສິ້ນສຸດ loader.
            },
            success:function(resp){
                if(resp == 1){
                    location.reload(); // ໂຫຼດໜ້າຄືນໃໝ່ຖ້າການລຶບສຳເລັດ.
                }else{
                    alert_toast("ເກີດຂໍ້ຜິດພາດ.","error"); // ສະແດງຂໍ້ຄວາມຜິດພາດ.
                    end_loader(); // ສິ້ນສຸດ loader.
                }
            }
        })
    }
 </script>