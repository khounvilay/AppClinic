<?php
 // ກວດສອບສະຖານະຂອງ Session. ຖ້າ Session ຍັງບໍ່ໄດ້ເລີ່ມ, ໃຫ້ເລີ່ມຕົ້ນມັນ.
 if (session_status() == PHP_SESSION_NONE) {
    session_start();
 }

 // ກໍານົດໂປຣໂຕຄອນ (http ຫຼື https) ຂອງ URL ປັດຈຸບັນ.
 if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on')
    $link = "https";
 else
    $link = "http";
 $link .= "://"; // ເພີ່ມ "://"
 $link .= $_SERVER['HTTP_HOST']; // ເພີ່ມຊື່ Host (ເຊັ່ນ: localhost, example.com)
 $link .= $_SERVER['REQUEST_URI']; // ເພີ່ມ URI ທີ່ຮ້ອງຂໍ (ເສັ້ນທາງແລະ query string)

 // ກວດສອບການເຂົ້າສູ່ລະບົບ:
 // ຖ້າບໍ່ມີຂໍ້ມູນຜູ້ໃຊ້ໃນ Session ($_SESSION['userdata'])
 // ແລະ URL ປັດຈຸບັນບໍ່ແມ່ນໜ້າ 'login.php',
 // ໃຫ້ປ່ຽນເສັ້ນທາງໄປໜ້າ admin/login.php.
 if(!isset($_SESSION['userdata']) && !strpos($link, 'login.php')){
    redirect('admin/login.php');
 }

 // ຖ້າມີຂໍ້ມູນຜູ້ໃຊ້ໃນ Session ແລ້ວ
 // ແລະ URL ປັດຈຸບັນແມ່ນໜ້າ 'login.php',
 // ໃຫ້ປ່ຽນເສັ້ນທາງໄປໜ້າ admin/index.php (ໜ້າຫຼັກຂອງລະບົບ).
 if(isset($_SESSION['userdata']) && strpos($link, 'login.php')){
    redirect('admin/index.php');
 }

 // ກໍານົດປະເພດຜູ້ໃຊ້ໂດຍອີງໃສ່ລະຫັດ login_type.
 // ຕົວຢ່າງ: array('','admin','faculty','student')
 // ໝາຍຄວາມວ່າ login_type 1 ຄື admin, 2 ຄື faculty, 3 ຄື student.
 $module = array('','admin','faculty','student');

 // ກວດສອບສິດການເຂົ້າເຖິງ:
 // ຖ້າມີຂໍ້ມູນຜູ້ໃຊ້ໃນ Session ແລ້ວ
 // ແລະ URL ປັດຈຸບັນມີຄຳວ່າ 'index.php' ຫຼື 'admin/',
 // ແຕ່ປະເພດການເຂົ້າສູ່ລະບົບຂອງຜູ້ໃຊ້ ($_SESSION['userdata']['login_type']) ບໍ່ແມ່ນ 1 (ເຊິ່ງກໍຄື admin),
 // ໃຫ້ສະແດງຂໍ້ຄວາມແຈ້ງເຕືອນ "Access Denied!" ແລະປ່ຽນເສັ້ນທາງໄປໜ້າຫຼັກຂອງປະເພດຜູ້ໃຊ້ນັ້ນໆ.
 if(isset($_SESSION['userdata']) && (strpos($link, 'index.php') || strpos($link, 'admin/')) && $_SESSION['userdata']['login_type'] !=  1){
    echo "<script>alert('Access Denied!');location.replace('".base_url.$module[$_SESSION['userdata']['login_type']]."');</script>";
    exit; // ຢຸດການເຮັດວຽກຂອງ Script.
 }
 ?>