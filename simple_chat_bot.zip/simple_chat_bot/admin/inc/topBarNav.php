<style>
  /* ແບບສີສຳລັບຮູບພາບຂອງຜູ້ໃຊ້ໃນແຖບນຳທາງ (Navbar). */
  .user-img{
        position: absolute; /* ຕັ້ງຕຳແໜ່ງຢ່າງແນ່ນອນ. */
        height: 27px; /* ກຳນົດຄວາມສູງ. */
        width: 27px; /* ກຳນົດຄວາມກວ້າງ. */
        object-fit: cover; /* ປັບຂະໜາດຮູບໃຫ້ເຕັມພື້ນທີ່ໂດຍບໍ່ບິດເບືອນອັດຕາສ່ວນ. */
        left: -7%; /* ປັບຕຳແໜ່ງຊ້າຍ. */
        top: -12%; /* ປັບຕຳແໜ່ງເທິງ. */
  }
  /* ແບບສີສຳລັບປຸ່ມທີ່ມີຂອບມົນ. */
  .btn-rounded{
        border-radius: 50px; /* ເຮັດໃຫ້ຂອບປຸ່ມມົນ. */
  }
 </style>
 <nav class="main-header navbar navbar-expand navbar-light shadow text-sm">
        <ul class="navbar-nav">
          <li class="nav-item">
          <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
          </li>
          <li class="nav-item d-none d-sm-inline-block">
            <a href="<?php echo base_url ?>" class="nav-link"><?php echo (!isMobileDevice()) ? $_settings->info('name'):$_settings->info('short_name'); ?> - Admin</a>
          </li>
        </ul>
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <div class="btn-group nav-link">
                  <button type="button" class="btn btn-rounded badge badge-light dropdown-toggle dropdown-icon" data-toggle="dropdown">
                    <span><img src="<?php echo validate_image($_settings->userdata('avatar')) ?>" class="img-circle elevation-2 user-img" alt="User Image"></span>
                    <span class="ml-3"><?php echo ucwords($_settings->userdata('firstname').' '.$_settings->userdata('lastname')) ?></span>
                    <span class="sr-only">Toggle Dropdown</span>
                  </button>
                  <div class="dropdown-menu" role="menu">
                    <a class="dropdown-item" href="<?php echo base_url.'admin/?page=user' ?>"><span class="fa fa-user"></span> ບັນຊີຂອງຂ້ອຍ</a>
                    <div class="dropdown-divider"></div> <a class="dropdown-item" href="<?php echo base_url.'/classes/Login.php?f=logout' ?>"><span class="fas fa-sign-out-alt"></span> ອອກຈາກລະບົບ</a>
                  </div>
              </div>
          </li>
          <li class="nav-item">

          </li>
         </ul>
      </nav>
  
