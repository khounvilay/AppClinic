<script>
  $(document).ready(function(){
    // ຟັງຊັນສຳລັບເປີດ Modal ເບິ່ງຮູບພາບ/ວິດີໂອ
    window.viewer_modal = function($src = ''){
      start_loader() // ເລີ່ມຕົ້ນສະແດງ Loading Spinner
      var t = $src.split('.') // ແຍກຊື່ໄຟລ໌ດ້ວຍຈຸດ (.) ເພື່ອເອົານາມສະກຸນ
      t = t[1] // ເອົານາມສະກຸນໄຟລ໌ (ເຊັ່ນ: 'mp4', 'jpg')
      if(t =='mp4'){ // ຖ້ານາມສະກຸນແມ່ນ 'mp4'
        var view = $("<video src='"+$src+"' controls autoplay></video>") // ສ້າງແທັກ <video>
      }else{ // ຖ້າບໍ່ແມ່ນ 'mp4' (ສົມມຸດວ່າເປັນຮູບພາບ)
        var view = $("<img src='"+$src+"' />") // ສ້າງແທັກ <img>
      }
      $('#viewer_modal .modal-content video,#viewer_modal .modal-content img').remove() // ລຶບວິດີໂອ ຫຼື ຮູບພາບເກົ່າອອກຈາກ modal
      $('#viewer_modal .modal-content').append(view) // ເພີ່ມວິດີໂອ ຫຼື ຮູບພາບໃໝ່ເຂົ້າໄປໃນ modal
      $('#viewer_modal').modal({
              show:true, // ສະແດງ modal
              backdrop:'static', // ຄລິກນອກ modal ບໍ່ໃຫ້ປິດ
              keyboard:false, // ກົດປຸ່ມ Esc ບໍ່ໃຫ້ປິດ
              focus:true // ກຳນົດໂຟກັສໃສ່ modal
            })
            end_loader()  // ສິ້ນສຸດການສະແດງ Loading Spinner
  }

    // ຟັງຊັນສຳລັບເປີດ Modal ແບບທົ່ວໄປ (uni_modal) ເພື່ອໂຫຼດເນື້ອໃນຈາກ URL
    window.uni_modal = function($title = '' , $url='',$size=""){
        start_loader() // ເລີ່ມຕົ້ນສະແດງ Loading Spinner
        $.ajax({
            url:$url, // URL ທີ່ຈະດຶງເນື້ອໃນມາ
            error:err=>{ // ຖ້າມີຂໍ້ຜິດພາດ
                console.log() // ພິມຂໍ້ຜິດພາດໃສ່ console
                alert("An error occured") // ສະແດງຂໍ້ຄວາມແຈ້ງເຕືອນ
            },
            success:function(resp){ // ຖ້າສຳເລັດ
                if(resp){ // ຖ້າມີການຕອບສະໜອງ
                    $('#uni_modal .modal-title').html($title) // ກຳນົດ Title ຂອງ modal
                    $('#uni_modal .modal-body').html(resp) // ກຳນົດເນື້ອໃນຂອງ modal ດ້ວຍຂໍ້ມູນທີ່ໄດ້ຮັບ
                    if($size != ''){ // ຖ້າມີການກຳນົດຂະໜາດ modal
                        $('#uni_modal .modal-dialog').addClass($size+'  modal-dialog-centered') // ເພີ່ມ class ຂະໜາດແລະຈັດກາງ
                    }else{
                        $('#uni_modal .modal-dialog').removeAttr("class").addClass("modal-dialog modal-md modal-dialog-centered") // ກຳນົດ class modal ເລີ່ມຕົ້ນ (ຂະໜາດກາງແລະຈັດກາງ)
                    }
                    $('#uni_modal').modal({
                      show:true, // ສະແດງ modal
                      backdrop:'static', // ຄລິກນອກ modal ບໍ່ໃຫ້ປິດ
                      keyboard:false, // ກົດປຸ່ມ Esc ບໍ່ໃຫ້ປິດ
                      focus:true // ກຳນົດໂຟກັສໃສ່ modal
                    })
                    end_loader() // ສິ້ນສຸດການສະແດງ Loading Spinner
                }
            }
        })
    }

    // ຟັງຊັນສຳລັບເປີດ Modal ຢືນຢັນ (confirm_modal)
    window._conf = function($msg='',$func='',$params = []){
       $('#confirm_modal #confirm').attr('onclick',$func+"("+$params.join(',')+")") // ກຳນົດຟັງຊັນທີ່ຈະຖືກເອີ້ນເມື່ອກົດປຸ່ມຢືນຢັນ
       $('#confirm_modal .modal-body').html($msg) // ກຳນົດຂໍ້ຄວາມໃນ modal
       $('#confirm_modal').modal('show') // ສະແດງ modal ຢືນຢັນ
    }
  })
</script>

<footer class="main-footer text-sm">
        <strong>Copyright © <?php echo date('Y') ?>. </strong>
        All rights reserved. <div class="float-right d-none d-sm-inline-block">
          <b><?php echo $_settings->info('short_name') ?> (by: <a href="#" target="blank">New</a> )</b> v1.0 </div>
      </footer>
    </div>
    <script>
      $.widget.bridge('uibutton', $.ui.button)
    </script>
    <script src="<?php echo base_url ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url ?>plugins/chart.js/Chart.min.js"></script>
    <script src="<?php echo base_url ?>plugins/sparklines/sparkline.js"></script>
    <script src="<?php echo base_url ?>plugins/select2/js/select2.full.min.js"></script>
    <script src="<?php echo base_url ?>plugins/jqvmap/jquery.vmap.min.js"></script>
    <script src="<?php echo base_url ?>plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
    <script src="<?php echo base_url ?>plugins/jquery-knob/jquery.knob.min.js"></script>
    <script src="<?php echo base_url ?>plugins/moment/moment.min.js"></script>
    <script src="<?php echo base_url ?>plugins/daterangepicker/daterangepicker.js"></script>
    <script src="<?php echo base_url ?>plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
    <script src="<?php echo base_url ?>plugins/summernote/summernote-bs4.min.js"></script>
    <script src="<?php echo base_url ?>plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url ?>plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo base_url ?>plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo base_url ?>plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script src="<?php echo base_url ?>dist/js/adminlte.js"></script>

    <div class="daterangepicker ltr show-ranges opensright">
      <div class="ranges">
        <ul>
          <li data-range-key="Today">ມື້ນີ້</li>
          <li data-range-key="Yesterday">ມື້ວານນີ້</li>
          <li data-range-key="Last 7 Days">7 ມື້ທີ່ຜ່ານມາ</li>
          <li data-range-key="Last 30 Days">30 ມື້ທີ່ຜ່ານມາ</li>
          <li data-range-key="This Month">ເດືອນນີ້</li>
          <li data-range-key="Last Month">ເດືອນທີ່ຜ່ານມາ</li>
          <li data-range-key="Custom Range">ໄລຍະກຳນົດເອງ</li>
        </ul>
      </div>
      <div class="drp-calendar left">
        <div class="calendar-table"></div>
        <div class="calendar-time" style="display: none;"></div>
      </div>
      <div class="drp-calendar right">
        <div class="calendar-table"></div>
        <div class="calendar-time" style="display: none;"></div>
      </div>
      <div class="drp-buttons"><span class="drp-selected"></span><button class="cancelBtn btn btn-sm btn-default" type="button">ຍົກເລີກ</button><button class="applyBtn btn btn-sm btn-primary" disabled="disabled" type="button">ນຳໃຊ້</button> </div>
    </div>
    <div class="jqvmap-label" style="display: none; left: 1093.83px; top: 394.361px;">ໄອ​ດາ​ໂຮ</div>