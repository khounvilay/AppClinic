<style>
  /* ແບບສີສຳລັບ Sidebar ຫຼັກ */
  aside.main-sidebar{
    /* ກຳນົດຮູບພາບພື້ນຫຼັງຂອງ Sidebar, ດຶງມາຈາກຂໍ້ມູນການຕັ້ງຄ່າ 'cover' ຂອງລະບົບ. */
    background-image:url('<?= validate_image($_settings->info('cover')) ?>') !important;
    /* ປັບຂະໜາດຮູບພາບໃຫ້ເຕັມພື້ນທີ່ຂອງ Sidebar */
    background-size:cover;
    /* ບໍ່ໃຫ້ຮູບພາບຊ້ຳກັນ */
    background-repeat:no-repeat;
    /* ຈັດຕຳແໜ່ງຮູບພາບຢູ່ຈຸດສູນກາງ */
    background-position:center center;
  }
</style>
<aside class="main-sidebar sidebar-dark-primary elevation-4 sidebar-no-expand">
        <a href="<?php echo base_url ?>admin" class="brand-link bg-gradient-navy text-sm">
        <img src="<?php echo validate_image($_settings->info('logo'))?>" alt="Store Logo" class="brand-image img-circle elevation-3" style="opacity: .8;width: 1.5rem;height: 1.5rem;max-height: unset">
        <span class="brand-text font-weight-light"><?php echo $_settings->info('short_name') ?></span>
        </a>
        <div class="sidebar os-host os-theme-light os-host-overflow os-host-overflow-y os-host-resize-disabled os-host-transition os-host-scrollbar-horizontal-hidden">
          <div class="os-resize-observer-host observed">
            <div class="os-resize-observer" style="left: 0px; right: auto;"></div>
          </div>
          <div class="os-size-auto-observer observed" style="height: calc(100% + 1px); float: left;">
            <div class="os-resize-observer"></div>
          </div>
          <div class="os-content-glue" style="margin: 0px -8px; width: 249px; height: 646px;"></div>
          <div class="os-padding">
            <div class="os-viewport os-viewport-native-scrollbars-invisible" style="overflow-y: scroll;">
              <div class="os-content" style="padding: 0px 8px; height: 100%; width: 100%;">
                <div class="clearfix"></div>
                <nav class="mt-4">
                   <ul class="nav nav-pills nav-sidebar flex-column text-sm nav-compact nav-flat nav-child-indent nav-collapse-hide-child" data-widget="treeview" role="menu" data-accordion="false">
                    <li class="nav-item dropdown">
                      <a href="./" class="nav-link nav-home">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>
                          ໜ້າຫຼັກ </p>
                      </a>
                    </li>
                    <li class="nav-item dropdown">
                      <a href="<?php echo base_url ?>admin/?page=responses" class="nav-link nav-responses">
                        <i class="nav-icon fas fa-comment-dots"></i>
                        <p>
                          ການຕອບສະໜອງ </p>
                      </a>
                    </li>
                    <li class="nav-item dropdown">
                      <a href="<?php echo base_url ?>admin/?page=reports" class="nav-link nav-reports">
                        <i class="nav-icon far fa-circle"></i>
                        <p>
                          ລາຍງານ </p>
                      </a>
                    </li>
                    <?php if($_settings->userdata('type') == 1): /* ກວດສອບວ່າຜູ້ໃຊ້ແມ່ນ Admin (type 1) */ ?>
                    <li class="nav-header">ການບໍາລຸງຮັກສາ </li>
                    <li class="nav-item dropdown">
                      <a href="<?php echo base_url ?>admin/?page=user/list" class="nav-link nav-user/list">
                        <i class="nav-icon fas fa-users-cog"></i>
                        <p>
                          ລາຍຊື່ຜູ້ໃຊ້ </p>
                      </a>
                    </li>
                    <li class="nav-item dropdown">
                      <a href="<?php echo base_url ?>admin/?page=system_info" class="nav-link nav-system_info">
                        <i class="nav-icon fas fa-tools"></i>
                        <p>
                          ການຕັ້ງຄ່າ </p>
                      </a>
                    </li>
                    <?php endif; ?>
                  </ul>
                </nav>
                </div>
            </div>
          </div>
          <div class="os-scrollbar os-scrollbar-horizontal os-scrollbar-unusable os-scrollbar-auto-hidden">
            <div class="os-scrollbar-track">
              <div class="os-scrollbar-handle" style="width: 100%; transform: translate(0px, 0px);"></div>
            </div>
          </div>
          <div class="os-scrollbar os-scrollbar-vertical os-scrollbar-auto-hidden">
            <div class="os-scrollbar-track">
              <div class="os-scrollbar-handle" style="height: 55.017%; transform: translate(0px, 0px);"></div>
            </div>
          </div>
          <div class="os-scrollbar-corner"></div>
        </div>
        </aside>
      <script>
    $(document).ready(function(){
      // ດຶງຄ່າ 'page' ຈາກ URL parameter, ຖ້າບໍ່ມີໃຫ້ໃຊ້ 'home'
      var page = '<?php echo isset($_GET['page']) ? $_GET['page'] : 'home' ?>';
      // ດຶງຄ່າ 's' ຈາກ URL parameter (ບໍ່ໄດ້ໃຊ້ໃນລະຫັດນີ້)
      var s = '<?php echo isset($_GET['s']) ? $_GET['s'] : '' ?>';
      // ແທນທີ່ເຄື່ອງໝາຍ '/' ໃນຊື່ page ດ້ວຍ '_' (ຕົວຢ່າງ: 'user/list' ກາຍເປັນ 'user_list')
      page = page.replace(/\//g,'_');
      console.log(page) // ພິມຊື່ page ທີ່ຖືກປັບປ່ຽນໃສ່ console

      // ກວດສອບວ່າລິ້ງນຳທາງຂອງໜ້າປັດຈຸບັນມີຢູ່ບໍ່
      if($('.nav-link.nav-'+page).length > 0){
             // ເພີ່ມ class 'active' ໃສ່ລິ້ງນຳທາງຂອງໜ້າປັດຈຸບັນ
             $('.nav-link.nav-'+page).addClass('active')
        // ຖ້າລິ້ງທີ່ active ເປັນ 'tree-item' (ລາຍການຍ່ອຍໃນເມນູຕົ້ນໄມ້)
        if($('.nav-link.nav-'+page).hasClass('tree-item') == true){
            // ເພີ່ມ class 'active' ໃສ່ລິ້ງແມ່ຂອງມັນ (siblings)
            $('.nav-link.nav-'+page).closest('.nav-treeview').siblings('a').addClass('active')
          // ເປີດເມນູຕົ້ນໄມ້ແມ່ (menu-open)
          $('.nav-link.nav-'+page).closest('.nav-treeview').parent().addClass('menu-open')
        }
        // ຖ້າລິ້ງທີ່ active ເປັນ 'nav-is-tree' (ແມ່ຂອງເມນູຕົ້ນໄມ້)
        if($('.nav-link.nav-'+page).hasClass('nav-is-tree') == true){
          // ເປີດເມນູຕົ້ນໄມ້ (menu-open)
          $('.nav-link.nav-'+page).parent().addClass('menu-open')
        }

      }
      // ເພີ່ມ class 'bg-gradient-navy' ໃສ່ລິ້ງທີ່ active ເພື່ອເນັ້ນສີພື້ນຫຼັງ
      $('.nav-link.active').addClass('bg-gradient-navy')
    })
  </script>