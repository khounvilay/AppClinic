<h1>ຍິນດີຕ້ອນຮັບ, <?php echo $_settings->userdata('firstname')." ".$_settings->userdata('lastname') ?>!</h1>
 <hr>
 <div class="row">
  <div class="col-12 col-sm-6 col-md-6">
   <div class="info-box">
    <span class="info-box-icon bg-gradient-navy elevation-1"><i class="fas fa-comment-dots"></i></span>
    <div class="info-box-content">
     <span class="info-box-text">ຈຳນວນຄຳຕອບທັງໝົດ</span>
     <span class="info-box-number">
      <?php
        // ດຶງຈໍານວນຄໍາຕອບທັງໝົດທີ່ມີສະຖານະເປັນ 1 (ເປີດໃຊ້ງານ).
        $responses = $conn->query("SELECT * FROM response_list where `status` = 1")->num_rows;
        echo format_num($responses); // ສະແດງຈໍານວນທີ່ຖືກ format ໄວ້.
      ?>
     </span>
    </div>
    </div>
   </div>
  <div class="col-12 col-sm-6 col-md-6">
   <div class="info-box">
    <span class="info-box-icon bg-gradient-light border elevation-1"><i class="fas fa-comments"></i></span>
    <div class="info-box-content">
     <span class="info-box-text">ຈຳນວນທີ່ຖືກຄົ້ນຫາທັງໝົດ</span>
     <span class="info-box-number">
      <?php
        // ດຶງຈໍານວນຄໍາຄົ້ນຫາທີ່ຖືກດຶງມາ (keyword_fetched) ທັງໝົດ.
        $total = $conn->query("SELECT * FROM keyword_fetched")->num_rows;
        echo format_num($total); // ສະແດງຈໍານວນທີ່ຖືກ format ໄວ້.
      ?>
     </span>
    </div>
    </div>
   </div>
 </div>
 <div class="container">
  <center>
  </center>
 </div>