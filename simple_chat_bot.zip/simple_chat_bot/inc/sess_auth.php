<?php
 // ຖ້າ (session_status() == PHP_SESSION_NONE) {
 //     session_start();
 // }
 // ບັນທັດເທິງນີ້ຖືກຄອມເມັ້ນໄວ້, ໂດຍປົກກະຕິແລ້ວມັນຈະເລີ່ມຕົ້ນ session ຖ້າຍັງບໍ່ໄດ້ເລີ່ມ.

 // ກໍານົດໂປຣໂຕຄໍ (http ຫຼື https) ທີ່ກໍາລັງໃຊ້.
 if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on')
     $link = "https";
 else
     $link = "http";
 $link .= "://"; // ເພີ່ມ "://" ຕໍ່ທ້າຍ.
 $link .= $_SERVER['HTTP_HOST']; // ເພີ່ມຊື່ host (ເຊັ່ນ: localhost, www.example.com).
 $link .= $_SERVER['REQUEST_URI']; // ເພີ່ມ URI ທີ່ຮ້ອງຂໍ (ເສັ້ນທາງແລະ query string).

 // ກວດສອບວ່າຜູ້ໃຊ້ຍັງບໍ່ໄດ້ເຂົ້າສູ່ລະບົບ (ບໍ່ມີຂໍ້ມູນ session 'userdata')
 // ແລະ URL ທີ່ກໍາລັງເຂົ້າເຖິງບໍ່ແມ່ນ 'login.php'.
 // ຖ້າທັງສອງເງື່ອນໄຂເປັນຈິງ, ໃຫ້ປ່ຽນເສັ້ນທາງໄປຫາໜ້າ login.php.
 if(!isset($_SESSION['userdata']) && !strpos($link, 'login.php')){
     redirect('login.php');
 }

 // ກວດສອບວ່າຜູ້ໃຊ້ໄດ້ເຂົ້າສູ່ລະບົບແລ້ວ (ມີຂໍ້ມູນ session 'userdata')
 // ແລະ URL ທີ່ກໍາລັງເຂົ້າເຖິງແມ່ນ 'login.php'.
 // ຖ້າທັງສອງເງື່ອນໄຂເປັນຈິງ, ໃຫ້ປ່ຽນເສັ້ນທາງໄປຫາໜ້າ index.php (ໜ້າຫຼັກ).
 if(isset($_SESSION['userdata']) && strpos($link, 'login.php')){
     redirect('index.php');
 }
 ?>