<nav class="navbar navbar-expand-lg navbar-dark bg-gradient-navy">
  <div class="container px-4 px-lg-5 ">
   <button class="navbar-toggler btn btn-sm" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
   </button>
   <a class="navbar-brand" href="./">
    <img src="<?php echo validate_image($_settings->info('logo')) ?>" width="30" height="30"
     class="d-inline-block align-top" alt="" loading="lazy">
    <?php echo $_settings->info('short_name') ?>
   </a>

   <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
    </ul>
    <div class="d-flex align-items-center">
     <a class="font-weight-bolder text-light mx-2 text-decoration-none" href="./admin">ເຂົ້າສູ່ລະບົບຜູ້ເບິ່ງແຍງລະບົບ</a>
    </div>
   </div>
  </div>
 </nav>
 <script>
  $(function() {
   // ເມື່ອຄລິກປຸ່ມເຂົ້າສູ່ລະບົບ, ຈະເປີດ modal ຟອມເຂົ້າສູ່ລະບົບ
   $('#login-btn').click(function() {
    uni_modal("", "login.php")
   })

   // ເມື່ອ navbar  responsive ສະແດງຂຶ້ນ, ໃຫ້ເພີ່ມ class 'navbar-shrink' ໃສ່ mainNav
   $('#navbarResponsive').on('show.bs.collapse', function() {
    $('#mainNav').addClass('navbar-shrink')
   })

   // ເມື່ອ navbar responsive ເຊື່ອງລົງ, ຖ້າໜ້າຈໍຢູ່ເທິງສຸດ (offset.top == 0), ໃຫ້ລຶບ class 'navbar-shrink' ອອກ
   $('#navbarResponsive').on('hidden.bs.collapse', function() {
    if ($('body').offset.top == 0)
     $('#mainNav').removeClass('navbar-shrink')
   })
  })

  // ເມື່ອແບບຟອມຄົ້ນຫາຖືກສົ່ງ, ປ້ອງກັນການໂຫຼດໜ້າຄືນໃໝ່ ແລະ ປ່ຽນເສັ້ນທາງໄປຫາໜ້າຜະລິດຕະພັນພ້ອມຄໍາຄົ້ນຫາ
  $('#search-form').submit(function(e) {
   e.preventDefault() // ປ້ອງກັນການໂຫຼດໜ້າຄືນໃໝ່
   var sTxt = $('[name="search"]').val() // ເອົາຄ່າຄົ້ນຫາ
   if (sTxt != '') // ຖ້າຄ່າຄົ້ນຫາບໍ່ຫວ່າງເປົ່າ
    location.href = './?p=products&search=' + sTxt; // ປ່ຽນເສັ້ນທາງ
  })
 </script>