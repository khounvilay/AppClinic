<?php global $_settings; ?>
 <script>
  $(document).ready(function() {
   // ເມື່ອຄລິກໃສ່ປຸ່ມ 'p_use', ຈະເປີດ modal "Privacy Policy"
   $('#p_use').click(function() {
    uni_modal("ນະໂຍບາຍຄວາມເປັນສ່ວນຕົວ", "policy.php", "mid-large")
   })

   // ຟັງຊັນສໍາລັບການເປີດ modal ເບິ່ງຮູບພາບ/ວິດີໂອ
   window.viewer_modal = function($src = '') {
    start_loader() // ເລີ່ມຕົ້ນ loading spinner
    var t = $src.split('.') // ແຍກຊື່ໄຟລ໌ເພື່ອເອົານາມສະກຸນ
    t = t[1] // ເອົານາມສະກຸນ
    if (t == 'mp4') { // ຖ້ານາມສະກຸນແມ່ນ mp4, ໃຫ້ສ້າງແທັກ video
     var view = $("<video src='" + $src + "' controls autoplay></video>")
    } else { // ຖ້າບໍ່ແມ່ນ mp4, ໃຫ້ສ້າງແທັກ img
     var view = $("<img src='" + $src + "' />")
    }
    // ລຶບເນື້ອຫາເກົ່າໃນ modal viewer
    $('#viewer_modal .modal-content video,#viewer_modal .modal-content img').remove()
    // ເພີ່ມເນື້ອຫາໃໝ່ (ຮູບພາບ ຫຼື ວິດີໂອ)
    $('#viewer_modal .modal-content').append(view)
    // ສະແດງ modal viewer
    $('#viewer_modal').modal({
     show: true,
     backdrop: 'static', // ປິດການຄລິກນອກ modal ເພື່ອປິດ
     keyboard: false, // ປິດການປິດດ້ວຍປຸ່ມ keyboard
     focus: true // ຕັ້ງຄ່າ focus ໃສ່ modal
    })
    end_loader() // ສິ້ນສຸດ loading spinner
   }

   // ຟັງຊັນສໍາລັບການເປີດ modal ທົ່ວໄປ (uni_modal)
   window.uni_modal = function($title = '', $url = '', $size = "") {
    start_loader() // ເລີ່ມຕົ້ນ loading spinner
    $.ajax({
     url: $url, // URL ທີ່ຈະໂຫຼດເນື້ອຫາຈາກ
     error: err => {
      console.log(err)
      alert("ເກີດຂໍ້ຜິດພາດ") // ສະແດງຂໍ້ຄວາມຜິດພາດ
     },
     success: function(resp) {
      if (resp) {
       $('#uni_modal .modal-title').html($title) // ຕັ້ງຊື່ຫົວຂໍ້ modal
       $('#uni_modal .modal-body').html(resp) // ໃສ່ເນື້ອຫາທີ່ໂຫຼດມາໃນ modal body
       if ($size != '') { // ຖ້າມີການກໍານົດຂະໜາດ, ໃຫ້ເພີ່ມ class ຂະໜາດ
        $('#uni_modal .modal-dialog').addClass($size + '  modal-dialog-centered')
       } else { // ຖ້າບໍ່ມີ, ໃຫ້ຕັ້ງຄ່າເລີ່ມຕົ້ນ
        $('#uni_modal .modal-dialog').removeAttr("class").addClass("modal-dialog modal-md modal-dialog-centered")
       }
       // ສະແດງ modal
       $('#uni_modal').modal({
        show: true,
        backdrop: 'static', // ປິດການຄລິກນອກ modal ເພື່ອປິດ
        keyboard: false, // ປິດການປິດດ້ວຍປຸ່ມ keyboard
        focus: true // ຕັ້ງຄ່າ focus ໃສ່ modal
       })
       end_loader() // ສິ້ນສຸດ loading spinner
      }
     }
    })
   }

   // ຟັງຊັນສໍາລັບການເປີດ modal ຢືນຢັນ (confirm_modal)
   window._conf = function($msg = '', $func = '', $params = []) {
    // ຕັ້ງຄ່າຟັງຊັນທີ່ຈະທໍາງານເມື່ອຄລິກປຸ່ມ 'Continue'
    $('#confirm_modal #confirm').attr('onclick', $func + "(" + $params.join(',') + ")")
    $('#confirm_modal .modal-body').html($msg) // ໃສ່ຂໍ້ຄວາມຢືນຢັນ
    $('#confirm_modal').modal('show') // ສະແດງ modal ຢືນຢັນ
   }
  })
 </script>
 <footer class="py-5 bg-gradient-navy">
  <div class="container">
   <p class="m-0 text-center text-white">ລິຂະສິດ &copy;
    <?php
    // ສາຍນີ້ເບິ່ງຄືວ່າມີຂໍ້ຜິດພາດທາງໄວຍາກອນ PHP ທີ່ $_settings = ;
    // ຄວນຈະເປັນ <?php echo $_settings->info('short_name');
    // ແຕ່ຂ້ອຍຈະແປຕາມທີ່ມັນຂຽນໄວ້, ໂດຍສັນນິຖານວ່າ 'short_name' ຈະຖືກດຶງມາຈາກອອບເຈັກ $_settings
    echo $_settings->info('short_name') ?> 2021</p>
   <p class="m-0 text-center text-white">ພັດທະນາໂດຍ: New</p>
  </div>
 </footer>


 <script>
  $.widget.bridge('uibutton', $.ui.button)
 </script>
 <script src="<?php echo base_url ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
 <script src="<?php echo base_url ?>plugins/chart.js/Chart.min.js"></script>
 <script src="<?php echo base_url ?>plugins/sparklines/sparkline.js"></script>
 <script src="<?php echo base_url ?>plugins/select2/js/select2.full.min.js"></script>
 <script src="<?php echo base_url ?>plugins/jqvmap/jquery.vmap.min.js"></script>
 <script src="<?php echo base_url ?>plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
 <script src="<?php echo base_url ?>plugins/jquery-knob/jquery.knob.min.js"></script>
 <script src="<?php echo base_url ?>plugins/moment/moment.min.js"></script>
 <script src="<?php echo base_url ?>plugins/daterangepicker/daterangepicker.js"></script>
 <script src="<?php echo base_url ?>plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
 <script src="<?php echo base_url ?>plugins/summernote/summernote-bs4.min.js"></script>
 <script src="<?php echo base_url ?>plugins/datatables/jquery.dataTables.min.js"></script>
 <script src="<?php echo base_url ?>plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
 <script src="<?php echo base_url ?>plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
 <script src="<?php echo base_url ?>plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
 <script src="<?php echo base_url ?>dist/js/adminlte.js"></script>
 <div class="daterangepicker ltr show-ranges opensright">
  <div class="ranges">
   <ul>
    <li data-range-key="Today">ມື້ນີ້</li>
    <li data-range-key="Yesterday">ມື້ວານນີ້</li>
    <li data-range-key="Last 7 Days">7 ມື້ຜ່ານມາ</li>
    <li data-range-key="Last 30 Days">30 ມື້ຜ່ານມາ</li>
    <li data-range-key="This Month">ເດືອນນີ້</li>
    <li data-range-key="Last Month">ເດືອນຜ່ານມາ</li>
    <li data-range-key="Custom Range">ຊ່ວງທີ່ກຳນົດເອງ</li>
   </ul>
  </div>
  <div class="drp-calendar left">
   <div class="calendar-table"></div>
   <div class="calendar-time" style="display: none;"></div>
  </div>
  <div class="drp-calendar right">
   <div class="calendar-table"></div>
   <div class="calendar-time" style="display: none;"></div>
  </div>
  <div class="drp-buttons"><span class="drp-selected"></span><button class="cancelBtn btn btn-sm btn-default"
    type="button">ຍົກເລີກ</button><button class="applyBtn btn btn-sm btn-primary" disabled="disabled"
    type="button">ນຳໃຊ້</button> </div>
 </div>
 <div class="jqvmap-label" style="display: none; left: 1093.83px; top: 394.361px;">Idaho</div>