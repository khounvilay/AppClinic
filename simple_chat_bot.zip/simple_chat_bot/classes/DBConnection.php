<?php
 // ກວດສອບວ່າຄ່າຄົງທີ່ 'DB_SERVER' ໄດ້ຖືກກໍານົດແລ້ວບໍ່.
 // ຖ້າບໍ່ທັນໄດ້ກໍານົດ, ມັນຈະລວມເອົາໄຟລ໌ 'initialize.php' ເຂົ້າມາ.
 // ໂດຍປົກກະຕິແລ້ວ, 'initialize.php' ຈະບັນຈຸຄໍານິຍາມຂອງຄ່າຄົງທີ່ຖານຂໍ້ມູນ (ເຊັ່ນ: DB_SERVER, DB_USERNAME, ແລະອື່ນໆ).
 if(!defined('DB_SERVER')){
     require_once("../initialize.php");
 }

 // ກໍານົດ class ຊື່ວ່າ DBConnection ເພື່ອຈັດການການເຊື່ອມຕໍ່ກັບຖານຂໍ້ມູນ.
 class DBConnection{

     // ຕົວແປ private ສໍາລັບຂໍ້ມູນການເຊື່ອມຕໍ່ຖານຂໍ້ມູນ.
     // ຄ່າເຫຼົ່ານີ້ຈະຖືກດຶງມາຈາກຄ່າຄົງທີ່ທີ່ກໍານົດໄວ້ໃນ 'initialize.php'.
     private $host = DB_SERVER;   // ຊື່ host ຂອງເຊີບເວີຖານຂໍ້ມູນ (ເຊັ່ນ: 'localhost').
     private $username = DB_USERNAME; // ຊື່ຜູ້ໃຊ້ຖານຂໍ້ມູນ.
     private $password = DB_PASSWORD; // ລະຫັດຜ່ານຖານຂໍ້ມູນ.
     private $database = DB_NAME; // ຊື່ຖານຂໍ້ມູນ.

     public $conn; // ຕົວແປ public ເພື່ອເກັບ object ການເຊື່ອມຕໍ່ຖານຂໍ້ມູນ.
                   // ນີ້ຈະສາມາດເຂົ້າເຖິງໄດ້ຈາກພາຍນອກ class.

     // Constructor method: ຖືກເອີ້ນໃຊ້ໂດຍອັດຕະໂນມັດເມື່ອ object ໃໝ່ຂອງ DBConnection ຖືກສ້າງຂຶ້ນ.
     public function __construct(){

         // ກວດສອບວ່າ object ການເຊື່ອມຕໍ່ ($this->conn) ຍັງບໍ່ທັນຖືກສ້າງຂຶ້ນ.
         if (!isset($this->conn)) {

             // ສ້າງການເຊື່ອມຕໍ່ຖານຂໍ້ມູນໂດຍໃຊ້ mysqli.
             // ມັນພະຍາຍາມເຊື່ອມຕໍ່ກັບຖານຂໍ້ມູນໂດຍໃຊ້ host, username, password, ແລະ database name ທີ່ກໍານົດໄວ້.
             $this->conn = new mysqli($this->host, $this->username, $this->password, $this->database);

             // ກວດສອບວ່າການເຊື່ອມຕໍ່ລົ້ມເຫຼວຫຼືບໍ່.
             if (!$this->conn) {
                 // ຖ້າເຊື່ອມຕໍ່ບໍ່ໄດ້, ໃຫ້ສະແດງຂໍ້ຄວາມຜິດພາດ.
                 echo 'Cannot connect to database server';
                 // ຢຸດການທໍາງານຂອງ script.
                 exit;
             }
         }

     }

     // Destructor method: ຖືກເອີ້ນໃຊ້ໂດຍອັດຕະໂນມັດເມື່ອ object ຖືກທໍາລາຍ (ເຊັ່ນ: ເມື່ອ script ສິ້ນສຸດລົງ).
     public function __destruct(){
         // ປິດການເຊື່ອມຕໍ່ຖານຂໍ້ມູນເພື່ອປ່ອຍຊັບພະຍາກອນ.
         $this->conn->close();
     }
 }
 ?>