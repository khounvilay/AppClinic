<?php
 // ຕ້ອງການໄຟລ໌ `config.php` ເຊິ່ງບັນຈຸການຕັ້ງຄ່າທົ່ວໄປ ແລະການເຊື່ອມຕໍ່ຖານຂໍ້ມູນ.
 require_once('../config.php');

 // Class `Users` ຈັດການການດໍາເນີນງານທີ່ກ່ຽວຂ້ອງກັບຜູ້ໃຊ້ (ເຊັ່ນ: ການບັນທຶກ, ການລຶບ).
 // ມັນສືບທອດມາຈາກ `DBConnection` ເພື່ອໃຊ້ຄວາມສາມາດໃນການເຊື່ອມຕໍ່ຖານຂໍ້ມູນ.
 class Users extends DBConnection {
    private $settings; // ຕົວແປສ່ວນຕົວເພື່ອເກັບ object ການຕັ້ງຄ່າລະບົບ.

    // Constructor ຂອງ Class `Users`.
    public function __construct(){
        global $_settings; // ເຂົ້າເຖິງ object ການຕັ້ງຄ່າທົ່ວໂລກ.
        $this->settings = $_settings; // ກໍານົດ object ການຕັ້ງຄ່າໃຫ້ກັບຕົວແປສ່ວນຕົວ.
        parent::__construct(); // ເອີ້ນ constructor ຂອງ Class ແມ່ `DBConnection` ເພື່ອສ້າງການເຊື່ອມຕໍ່ຖານຂໍ້ມູນ.
    }

    // Destructor ຂອງ Class `Users`.
    public function __destruct(){
        parent::__destruct(); // ເອີ້ນ destructor ຂອງ Class ແມ່ ເພື່ອປິດການເຊື່ອມຕໍ່ຖານຂໍ້ມູນ.
    }

    // ຟັງຊັນສໍາລັບການບັນທຶກ ຫຼື ອັບເດດຂໍ້ມູນຜູ້ໃຊ້.
    public function save_users(){
        // ຖ້າລະຫັດຜ່ານຫວ່າງເປົ່າ, ໃຫ້ຍົກເລີກມັນອອກຈາກ $_POST ເພື່ອບໍ່ໃຫ້ອັບເດດລະຫັດຜ່ານ.
        if(empty($_POST['password']))
            unset($_POST['password']);
        else
            // ຖ້າລະຫັດຜ່ານບໍ່ຫວ່າງເປົ່າ, ໃຫ້ເຂົ້າລະຫັດດ້ວຍ MD5.
            // (ຂໍ້ຄວນລະວັງ: MD5 ບໍ່ປອດໄພສໍາລັບລະຫັດຜ່ານໃນການຜະລິດ, ຄວນໃຊ້ bcrypt ຫຼື Argon2).
            $_POST['password'] = md5($_POST['password']);

        extract($_POST); // ແຍກຕົວແປຈາກ $_POST array (ເຊັ່ນ: $id, $username, $password, ແລະອື່ນໆ).
        $data = ''; // ສາຍຂໍ້ຄວາມເພື່ອສ້າງສ່ວນ SET ຂອງຄໍາສັ່ງ SQL.

        // ວົນລູບຜ່ານຂໍ້ມູນ $_POST ເພື່ອສ້າງ string ຂອງຄູ່ key-value ສໍາລັບ SQL.
        foreach($_POST as $k => $v){
            if(!in_array($k,array('id'))){ // ຍົກເວັ້ນ 'id' ເພາະມັນຖືກໃຊ້ໃນເງື່ອນໄຂ WHERE.
                if(!empty($data)) $data .=" , "; // ເພີ່ມເຄື່ອງໝາຍຈຸດຄັ່ນຖ້າບໍ່ແມ່ນຄູ່ທໍາອິດ.
                $data .= " {$k} = '{$v}' "; // ເພີ່ມຄູ່ key-value.
            }
        }

        // ຖ້າ $id ຫວ່າງເປົ່າ, ໝາຍຄວາມວ່າເປັນການສ້າງຜູ້ໃຊ້ໃໝ່.
        if(empty($id)){
            $qry = $this->conn->query("INSERT INTO users set {$data}"); // ປະຕິບັດຄໍາສັ່ງ INSERT.
            if($qry){ // ຖ້າ Query ສໍາເລັດ.
                $id=$this->conn->insert_id; // ໄດ້ຮັບ ID ທີ່ຖືກໃສ່ລ່າສຸດ.
                $this->settings->set_flashdata('success','ລາຍລະອຽດຜູ້ໃຊ້ຖືກບັນທຶກສຳເລັດແລ້ວ.'); // ຕັ້ງຄ່າຂໍ້ຄວາມ Flashdata.

                // ອັບເດດຂໍ້ມູນຜູ້ໃຊ້ໃນ session ຖ້າຜູ້ໃຊ້ທີ່ບັນທຶກແມ່ນຜູ້ໃຊ້ທີ່ເຂົ້າສູ່ລະບົບປະຈຸບັນ.
                foreach($_POST as $k => $v){
                    if($k != 'id'){
                        if(!empty($data)) $data .=" , ";
                        if($this->settings->userdata('id') == $id)
                        $this->settings->set_userdata($k,$v);
                    }
                }

                // ຈັດການການອັບໂຫຼດຮູບພາບ Avatar.
                if(!empty($_FILES['img']['tmp_name'])){
                    // ສ້າງໄດເຣັກທໍຣີ `uploads/avatars` ຖ້າບໍ່ມີ.
                    if(!is_dir(base_app."uploads/avatars"))
                        mkdir(base_app."uploads/avatars");
                    $ext = pathinfo($_FILES['img']['name'], PATHINFO_EXTENSION); // ໄດ້ຮັບນາມສະກຸນໄຟລ໌.
                    $fname = "uploads/avatars/$id.png"; // ກໍານົດຊື່ໄຟລ໌.
                    $accept = array('image/jpeg','image/png'); // ປະເພດໄຟລ໌ທີ່ອະນຸຍາດ.

                    // ກວດສອບປະເພດໄຟລ໌.
                    if(!in_array($_FILES['img']['type'],$accept)){
                        $err = "ປະເພດໄຟລ໌ຮູບພາບບໍ່ຖືກຕ້ອງ";
                    }
                    // ສ້າງຮູບພາບຈາກໄຟລ໌ທີ່ອັບໂຫຼດ.
                    if($_FILES['img']['type'] == 'image/jpeg')
                        $uploadfile = imagecreatefromjpeg($_FILES['img']['tmp_name']);
                    elseif($_FILES['img']['type'] == 'image/png')
                        $uploadfile = imagecreatefrompng($_FILES['img']['tmp_name']);

                    // ກວດສອບຄວາມຖືກຕ້ອງຂອງຮູບພາບ.
                    if(!$uploadfile){
                        $err = "ຮູບພາບບໍ່ຖືກຕ້ອງ";
                    }
                    $temp = imagescale($uploadfile,200,200); // ປັບຂະໜາດຮູບພາບເປັນ 200x200 ພິກເຊວ.
                    if(is_file(base_app.$fname)) // ຖ້າມີໄຟລ໌ເກົ່າ, ໃຫ້ລຶບມັນ.
                    unlink(base_app.$fname);
                    $upload =imagepng($temp,base_app.$fname); // ບັນທຶກຮູບພາບທີ່ປັບຂະໜາດແລ້ວເປັນ PNG.

                    if($upload){ // ຖ້າການອັບໂຫຼດສຳເລັດ.
                        // ອັບເດດ path ຂອງ avatar ໃນຖານຂໍ້ມູນ.
                        $this->conn->query("UPDATE `users` set `avatar` = CONCAT('{$fname}', '?v=',unix_timestamp(CURRENT_TIMESTAMP)) where id = '{$id}'");
                        // ອັບເດດ avatar ໃນ session ຖ້າຜູ້ໃຊ້ທີ່ເຂົ້າສູ່ລະບົບແມ່ນຜູ້ໃຊ້ຄົນນີ້.
                        if($this->settings->userdata('id') == $id)
                        $this->settings->set_userdata('avatar',$fname."?v=".time());
                    }
                    imagedestroy($temp); // ລຶບຮູບພາບຊົ່ວຄາວອອກຈາກ memory.
                }
                return 1; // ສົ່ງຄືນ 1 ເພື່ອບອກວ່າສຳເລັດ.
            }else{
                return 2; // ສົ່ງຄືນ 2 ເພື່ອບອກວ່າລົ້ມເຫຼວ.
            }

        }else{ // ຖ້າ $id ບໍ່ຫວ່າງເປົ່າ, ໝາຍຄວາມວ່າເປັນການອັບເດດຜູ້ໃຊ້.
            $qry = $this->conn->query("UPDATE users set $data where id = {$id}"); // ປະຕິບັດຄໍາສັ່ງ UPDATE.
            if($qry){ // ຖ້າ Query ສໍາເລັດ.
                $this->settings->set_flashdata('success','ລາຍລະອຽດຜູ້ໃຊ້ຖືກອັບເດດສຳເລັດແລ້ວ.'); // ຕັ້ງຄ່າຂໍ້ຄວາມ Flashdata.

                // ອັບເດດຂໍ້ມູນຜູ້ໃຊ້ໃນ session ຖ້າຜູ້ໃຊ້ທີ່ອັບເດດແມ່ນຜູ້ໃຊ້ທີ່ເຂົ້າສູ່ລະບົບປະຈຸບັນ.
                foreach($_POST as $k => $v){
                    if($k != 'id'){
                        if(!empty($data)) $data .=" , ";
                        if($this->settings->userdata('id') == $id)
                            $this->settings->set_userdata($k,$v);
                    }
                }

                // ຈັດການການອັບໂຫຼດຮູບພາບ Avatar (ຂະບວນການຄືກັນກັບການສ້າງໃໝ່).
                if(!empty($_FILES['img']['tmp_name'])){
                    if(!is_dir(base_app."uploads/avatars"))
                        mkdir(base_app."uploads/avatars");
                    $ext = pathinfo($_FILES['img']['name'], PATHINFO_EXTENSION);
                    $fname = "uploads/avatars/$id.png";
                    $accept = array('image/jpeg','image/png');
                    if(!in_array($_FILES['img']['type'],$accept)){
                        $err = "ປະເພດໄຟລ໌ຮູບພາບບໍ່ຖືກຕ້ອງ";
                    }
                    if($_FILES['img']['type'] == 'image/jpeg')
                        $uploadfile = imagecreatefromjpeg($_FILES['img']['tmp_name']);
                    elseif($_FILES['img']['type'] == 'image/png')
                        $uploadfile = imagecreatefrompng($_FILES['img']['tmp_name']);
                    if(!$uploadfile){
                        $err = "ຮູບພາບບໍ່ຖືກຕ້ອງ";
                    }
                    $temp = imagescale($uploadfile,200,200);
                    if(is_file(base_app.$fname))
                    unlink(base_app.$fname);
                    $upload =imagepng($temp,base_app.$fname);
                    if($upload){
                        $this->conn->query("UPDATE `users` set `avatar` = CONCAT('{$fname}', '?v=',unix_timestamp(CURRENT_TIMESTAMP)) where id = '{$id}'");
                        if($this->settings->userdata('id') == $id)
                        $this->settings->set_userdata('avatar',$fname."?v=".time());
                    }
                    imagedestroy($temp);
                }
                return 1; // ສົ່ງຄືນ 1 ເພື່ອບອກວ່າສຳເລັດ.
            }else{
                return "UPDATE users set $data where id = {$id}"; // ສົ່ງຄືນຄໍາສັ່ງ SQL ຖ້າລົ້ມເຫຼວ (ສໍາລັບ Debug).
            }
        }
    }

    // ຟັງຊັນສໍາລັບການລຶບຜູ້ໃຊ້.
    public function delete_users(){
        extract($_POST); // ແຍກຕົວແປຈາກ $_POST array (ເຊັ່ນ: $id).
        $qry = $this->conn->query("DELETE FROM users where id = $id"); // ປະຕິບັດຄໍາສັ່ງ DELETE.
        if($qry){ // ຖ້າ Query ສໍາເລັດ.
            $this->settings->set_flashdata('success','ລາຍລະອຽດຜູ້ໃຊ້ຖືກລຶບສຳເລັດແລ້ວ.'); // ຕັ້ງຄ່າຂໍ້ຄວາມ Flashdata.
            // ລຶບໄຟລ໌ avatar ຂອງຜູ້ໃຊ້ຖ້າມີຢູ່.
            if(is_file(base_app."uploads/avatars/$id.png"))
                unlink(base_app."uploads/avatars/$id.png");
            return 1; // ສົ່ງຄືນ 1 ເພື່ອບອກວ່າສຳເລັດ.
        }else{
            return false; // ສົ່ງຄືນ false ຖ້າລົ້ມເຫຼວ.
        }
    }
 }

 // ສ້າງ instance ຂອງ Class `Users`.
 $users = new Users();
 // ກໍານົດການກະທໍາໂດຍອີງໃສ່ parameter 'f' ໃນ URL.
 $action = !isset($_GET['f']) ? 'none' : strtolower($_GET['f']);

 // Switch case ເພື່ອປະຕິບັດຟັງຊັນທີ່ກ່ຽວຂ້ອງກັບການກະທໍາ.
 switch ($action) {
    case 'save':
        echo $users->save_users(); // ເອີ້ນຟັງຊັນ `save_users`.
    break;
    case 'delete':
        echo $users->delete_users(); // ເອີ້ນຟັງຊັນ `delete_users`.
    break;
    default:
        // echo $sysset->index(); // ຖືກຄອມເມັ້ນໄວ້, ບໍ່ມີການປະຕິບັດງານເລີ່ມຕົ້ນສະເພາະ.
        break;
 }
 ?>