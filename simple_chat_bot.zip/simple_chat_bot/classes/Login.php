<?php
 require_once '../config.php'; // ລວມເອົາໄຟລ໌ config.php ເຊິ່ງອາດຈະບັນຈຸການຕັ້ງຄ່າຖານຂໍ້ມູນ ແລະຟັງຊັນທີ່ຈໍາເປັນ.

 class Login extends DBConnection { // ສ້າງຄລາດ Login ທີ່ສືບທອດມາຈາກຄລາດ DBConnection.
    private $settings; // ຕົວແປ private ເພື່ອເກັບ object ການຕັ້ງຄ່າ (settings).

    public function __construct(){
        global $_settings; // ເຂົ້າເຖິງຕົວແປ global $_settings.
        $this->settings = $_settings; // ກໍານົດ object ການຕັ້ງຄ່າໃຫ້ກັບຕົວແປ private.

        parent::__construct(); // ເອີ້ນໃຊ້ constructor ຂອງຄລາດແມ່ (DBConnection) ເພື່ອສ້າງການເຊື່ອມຕໍ່ຖານຂໍ້ມູນ.
        ini_set('display_error', 1); // ຕັ້ງຄ່າໃຫ້ສະແດງຂໍ້ຜິດພາດ PHP (ຄວນປິດໃນ production).
    }

    public function __destruct(){
        parent::__destruct(); // ເອີ້ນໃຊ້ destructor ຂອງຄລາດແມ່ເພື່ອປິດການເຊື່ອມຕໍ່ຖານຂໍ້ມູນ.
    }

    public function index(){
        // ຟັງຊັນນີ້ຈະຖືກເອີ້ນໃຊ້ຖ້າບໍ່ມີການລະບຸການກະທຳທີ່ຊັດເຈນ.
        echo "<h1>ການເຂົ້າເຖິງຖືກປະຕິເສດ</h1> <a href='".base_url."'>ກັບຄືນ.</a>";
    }

    public function login(){
        extract($_POST); // ແຍກຂໍ້ມູນຈາກ $_POST array ໃຫ້ກາຍເປັນຕົວແປ.

        // ສ້າງຄໍາສັ່ງ SQL ແບບ PreparedStatement ເພື່ອປ້ອງກັນ SQL Injection.
        $stmt = $this->conn->prepare("SELECT * from users where username = ? and password = ? ");
        $password = md5($password); // ເຂົ້າລະຫັດລະຫັດຜ່ານດ້ວຍ MD5 (ບໍ່ແນະນໍາໃຫ້ໃຊ້ໃນການຜະລິດຍ້ອນຄວາມປອດໄພຕໍ່າ).
        $stmt->bind_param('ss',$username,$password); // ຜູກມັດຄ່າ username ແລະ password ໃສ່ກັບ PreparedStatement.
        $stmt->execute(); // ປະຕິບັດຄໍາສັ່ງ SQL.
        $result = $stmt->get_result(); // ໄດ້ຮັບຜົນລັບຈາກການສອບຖາມ.

        if($result->num_rows > 0){ // ຖ້າມີແຖວຂໍ້ມູນທີ່ກົງກັນ (ຜູ້ໃຊ້ພົບ).
            foreach($result->fetch_array() as $k => $v){
                if(!is_numeric($k) && $k != 'password'){
                    // ເກັບຂໍ້ມູນຜູ້ໃຊ້ເຂົ້າໃນ session, ຍົກເວັ້ນຄ່າຕົວເລກ (numeric keys) ແລະ ລະຫັດຜ່ານ.
                    $this->settings->set_userdata($k,$v);
                }
            }
            $this->settings->set_userdata('login_type',1); // ຕັ້ງຄ່າປະເພດການເຂົ້າສູ່ລະບົບ (1 ສໍາລັບຜູ້ໃຊ້ທົ່ວໄປ).
            return json_encode(array('status'=>'success')); // ສົ່ງຄືນສະຖານະ 'success'.
        }else{
            // ຖ້າບໍ່ພົບຜູ້ໃຊ້.
            return json_encode(array('status'=>'incorrect','last_qry'=>"SELECT * from users where username = '$username' and password = md5('$password') "));
            // ສົ່ງຄືນສະຖານະ 'incorrect' ພ້ອມກັບ query ສຸດທ້າຍ (ສໍາລັບ debug).
        }
    }

    public function logout(){
        // ຟັງຊັນອອກຈາກລະບົບສໍາລັບຜູ້ໃຊ້ທົ່ວໄປ.
        if($this->settings->sess_des()){ // ລຶບ session ຂອງຜູ້ໃຊ້.
            redirect('admin/login.php'); // ປ່ຽນເສັ້ນທາງໄປໜ້າ login ຂອງ admin.
        }
    }

    function login_agent(){
        extract($_POST); // ແຍກຂໍ້ມູນຈາກ $_POST array.
        // ສ້າງຄໍາສັ່ງ SQL ແບບ PreparedStatement ສໍາລັບການເຂົ້າສູ່ລະບົບຂອງຕົວແທນ (agent).
        $stmt = $this->conn->prepare("SELECT * from agent_list where email = ? and `password` = ? and delete_flag = 0 ");
        $password = md5($password); // ເຂົ້າລະຫັດລະຫັດຜ່ານດ້ວຍ MD5.
        $stmt->bind_param('ss',$email,$password); // ຜູກມັດຄ່າ email ແລະ password.
        $stmt->execute(); // ປະຕິບັດຄໍາສັ່ງ SQL.
        $result = $stmt->get_result(); // ໄດ້ຮັບຜົນລັບ.
        $resp = array(); // ສ້າງອາເຣເປົ່າສໍາລັບການຕອບສະໜອງ.

        if($result->num_rows > 0){ // ຖ້າມີແຖວຂໍ້ມູນທີ່ກົງກັນ.
            $res = $result->fetch_array(); // ດຶງຂໍ້ມູນຜູ້ໃຊ້.
            if($res['status'] == 1){ // ກວດສອບສະຖານະຂອງຕົວແທນ (1 ໝາຍເຖິງເປີດໃຊ້ງານ).
                foreach($res as $k => $v){
                    // ເກັບຂໍ້ມູນຕົວແທນເຂົ້າໃນ session.
                    $this->settings->set_userdata($k,$v);
                }
                $this->settings->set_userdata('login_type',2); // ຕັ້ງຄ່າປະເພດການເຂົ້າສູ່ລະບົບ (2 ສໍາລັບຕົວແທນ).
                $resp['status'] = 'success'; // ຕັ້ງສະຖານະເປັນ 'success'.
            }else{
                $resp['status'] = 'failed'; // ຕັ້ງສະຖານະເປັນ 'failed'.
                $resp['msg'] = 'ບັນຊີຂອງທ່ານຖືກບລັອກ.'; // ຂໍ້ຄວາມຜິດພາດ.
            }
        }else{
            $resp['status'] = 'failed'; // ຕັ້ງສະຖານະເປັນ 'failed'.
            $resp['msg'] = 'ອີເມວ ຫຼື ລະຫັດຜ່ານບໍ່ຖືກຕ້ອງ'; // ຂໍ້ຄວາມຜິດພາດ.
        }
        if($this->conn->error){ // ກວດສອບຂໍ້ຜິດພາດຂອງການເຊື່ອມຕໍ່ຖານຂໍ້ມູນ.
            $resp['status'] = 'failed';
            $resp['_error'] = $this->conn->error; // ເກັບຂໍ້ຜິດພາດຂອງຖານຂໍ້ມູນ (ສໍາລັບ debug).
        }
        return json_encode($resp); // ສົ່ງຄືນຜົນລັບໃນຮູບແບບ JSON.
    }

    public function logout_agent(){
        // ຟັງຊັນອອກຈາກລະບົບສໍາລັບຕົວແທນ.
        if($this->settings->sess_des()){ // ລຶບ session ຂອງຕົວແທນ.
            redirect('agent'); // ປ່ຽນເສັ້ນທາງໄປໜ້າຫຼັກຂອງຕົວແທນ.
        }
    }
 }

 // ກວດສອບວ່າຕົວແປ GET 'f' ຖືກກໍານົດແລ້ວບໍ່.
 // ຖ້າບໍ່, ຕັ້ງຄ່າການກະທໍາເປັນ 'none', ຖ້າບໍ່, ຕັ້ງຄ່າການກະທໍາຕາມຄ່າຂອງ 'f' (ເປັນຕົວພິມນ້ອຍ).
 $action = !isset($_GET['f']) ? 'none' : strtolower($_GET['f']);
 $auth = new Login(); // ສ້າງ object ໃໝ່ຂອງຄລາດ Login.

 // ໃຊ້ switch case ເພື່ອປະຕິບັດການກະທໍາທີ່ກົງກັນ.
 switch ($action) {
    case 'login':
        echo $auth->login(); // ເຂົ້າສູ່ລະບົບຜູ້ໃຊ້.
        break;
    case 'logout':
        echo $auth->logout(); // ອອກຈາກລະບົບຜູ້ໃຊ້.
        break;
    case 'login_agent':
        echo $auth->login_agent(); // ເຂົ້າສູ່ລະບົບຕົວແທນ.
        break;
    case 'logout_agent':
        echo $auth->logout_agent(); // ອອກຈາກລະບົບຕົວແທນ.
        break;
    default:
        echo $auth->index(); // ຖ້າບໍ່ມີການກະທໍາໃດກົງກັນ, ສະແດງໜ້າ 'Access Denied'.
        break;
 }
 ?>