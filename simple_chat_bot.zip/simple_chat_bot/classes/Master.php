<?php
 require_once('../config.php'); // ຮຽກໃຊ້ໄຟລ໌ config.php ເຊິ່ງບັນຈຸການຕັ້ງຄ່າພື້ນຖານຂອງລະບົບ ແລະການເຊື່ອມຕໍ່ຖານຂໍ້ມູນ.

 Class Master extends DBConnection { // ສ້າງ Class ຊື່ Master ທີ່ສືບທອດມາຈາກ Class DBConnection.
    private $settings; // ປະກາດຕົວແປ private $settings ເພື່ອເກັບ object ຂອງ SystemSettings.

    public function __construct(){
        global $_settings; // ເຂົ້າເຖິງຕົວແປ global $_settings ທີ່ບັນຈຸການຕັ້ງຄ່າລະບົບ.
        $this->settings = $_settings; // ກໍານົດ object $_settings ໃຫ້ກັບຕົວແປ $this->settings.
        parent::__construct(); // ເອີ້ນໃຊ້ constructor ຂອງ Class ແມ່ (DBConnection) ເພື່ອສ້າງການເຊື່ອມຕໍ່ຖານຂໍ້ມູນ.
    }

    public function __destruct(){
        parent::__destruct(); // ເອີ້ນໃຊ້ destructor ຂອງ Class ແມ່ ເພື່ອປິດການເຊື່ອມຕໍ່ຖານຂໍ້ມູນເມື່ອ object ຖືກທໍາລາຍ.
    }

    // ຟັງຊັນສໍາລັບການເກັບຂໍ້ຜິດພາດຂອງຖານຂໍ້ມູນ.
    function capture_err(){
        if(!$this->conn->error) // ຖ້າບໍ່ມີຂໍ້ຜິດພາດໃນການເຊື່ອມຕໍ່ຖານຂໍ້ມູນ.
            return false; // ສົ່ງຄືນ false.
        else{
            $resp['status'] = 'failed'; // ຕັ້ງຄ່າສະຖານະເປັນ 'failed'.
            $resp['error'] = $this->conn->error; // ເກັບຂໍ້ຄວາມຜິດພາດຂອງຖານຂໍ້ມູນ.
            return json_encode($resp); // ສົ່ງຄືນຂໍ້ຄວາມຜິດພາດໃນຮູບແບບ JSON.
            exit; // ຢຸດການເຮັດວຽກຂອງ script.
        }
    }

    // ຟັງຊັນສໍາລັບການລຶບຮູບພາບ.
    function delete_img(){
        extract($_POST); // ແຍກຂໍ້ມູນທີ່ສົ່ງມາຈາກ $_POST ເຂົ້າໄປໃນຕົວແປ.
        if(is_file($path)){ // ກວດສອບວ່າໄຟລ໌ມີຢູ່ທີ່ເສັ້ນທາງ $path ທີ່ລະບຸໄວ້ບໍ່.
            if(unlink($path)){ // ພະຍາຍາມລຶບໄຟລ໌.
                $resp['status'] = 'success'; // ຖ້າລຶບສຳເລັດ, ຕັ້ງຄ່າສະຖານະເປັນ 'success'.
            }else{
                $resp['status'] = 'failed'; // ຖ້າລຶບບໍ່ສຳເລັດ, ຕັ້ງຄ່າສະຖານະເປັນ 'failed'.
                $resp['error'] = 'failed to delete '.$path; // ລະບຸຂໍ້ຜິດພາດ.
            }
        }else{
            $resp['status'] = 'failed'; // ຖ້າໄຟລ໌ບໍ່ມີຢູ່.
            $resp['error'] = 'Unknown '.$path.' path'; // ລະບຸຂໍ້ຜິດພາດວ່າເສັ້ນທາງບໍ່ຮູ້ຈັກ.
        }
        return json_encode($resp); // ສົ່ງຄືນຜົນລັບໃນຮູບແບບ JSON.
    }

    // ຟັງຊັນສໍາລັບການບັນທຶກ ຫຼື ອັບເດດຄໍາຕອບ (response).
    function save_response(){
        extract($_POST); // ແຍກຂໍ້ມູນທີ່ສົ່ງມາຈາກ $_POST.
        $data = ""; // ປະກາດຕົວແປ $data ເພື່ອເກັບຄໍາສັ່ງ SQL ສໍາລັບການໃສ່/ອັບເດດຂໍ້ມູນ.

        // ວົນລູບຜ່ານຂໍ້ມູນທີ່ສົ່ງມາເພື່ອສ້າງສ່ວນຂອງ SQL query.
        foreach($_POST as $k =>$v){
            // ຍົກເວັ້ນ 'id', 'keyword', ແລະ 'suggestion' ເພາະຈະຖືກຈັດການແຍກຕ່າງຫາກ.
            if(!in_array($k,['id', 'keyword', 'suggestion'])){
                if(!empty($data)) $data .=","; // ເພີ່ມເຄື່ອງໝາຍ comma ຖ້າບໍ່ແມ່ນລາຍການທໍາອິດ.
                $v = $this->conn->real_escape_string($v); // ປ້ອງກັນ SQL Injection.
                $data .= " `{$k}`='{$v}' "; // ເພີ່ມຄູ່ key-value ໃສ່ $data.
            }
        }

        $kw_arr=[]; // ອາເຣເພື່ອເກັບຄໍາຫຼັກ (keywords).
        foreach($keyword as $k => $v){ // ວົນລູບຜ່ານຄໍາຫຼັກທີ່ສົ່ງມາ.
            $v  = trim($this->conn->real_escape_string($v)); // ທໍາຄວາມສະອາດ ແລະ ປ້ອງກັນ SQL Injection.

            // ກວດສອບວ່າມີຄໍາຫຼັກນີ້ຢູ່ໃນລະບົບແລ້ວບໍ່ ເພື່ອຫຼີກເວັ້ນຄວາມຊໍ້າຊ້ອນທີ່ອາດຈະສ້າງບັນຫາ.
            $check = $this->conn->query("SELECT keyword FROM `keyword_list` where keyword = '{$v}'".(!empty($id) ? " and response_id != '{$id}' " : ""))->num_rows;
            if($check > 0){
                $resp['status'] = 'failed';
                $resp['msg'] = 'ຄໍາຫຼັກນີ້ມີຢູ່ແລ້ວ. ນີ້ອາດຈະເຮັດໃຫ້ການດຶງຄໍາຕອບສັບສົນ.';
                $resp['kw_index'] = $k; // ລະບຸ index ຂອງຄໍາຫຼັກທີ່ມີບັນຫາ.
                return json_encode($resp); // ສົ່ງຄືນຂໍ້ຄວາມຜິດພາດ.
            }
            $kw_arr[]= $v; // ເພີ່ມຄໍາຫຼັກໃສ່ອາເຣ.
        }

        // ກໍານົດຄໍາສັ່ງ SQL ສໍາລັບ INSERT ຫຼື UPDATE.
        if(empty($id)){
            $sql = "INSERT INTO `response_list` set {$data} "; // INSERT ຖ້າບໍ່ມີ id.
        }else{
            $sql = "UPDATE `response_list` set {$data} where id = '{$id}' "; // UPDATE ຖ້າມີ id.
        }

        $save = $this->conn->query($sql); // ປະຕິບັດຄໍາສັ່ງ SQL.
        if($save){ // ຖ້າການບັນທຶກສຳເລັດ.
            $rid = !empty($id) ? $id : $this->conn->insert_id; // ໄດ້ຮັບ ID ຂອງຄໍາຕອບ.
            $resp['rid'] = $rid; // ເກັບ response ID.
            $resp['status'] = 'success'; // ຕັ້ງສະຖານະເປັນ 'success'.
            if(empty($id))
                $resp['msg'] = "ບັນທຶກຄໍາຕອບໃໝ່ສຳເລັດແລ້ວ."; // ຂໍ້ຄວາມສຳເລັດສໍາລັບການສ້າງໃໝ່.
            else
                $resp['msg'] = "ອັບເດດຄໍາຕອບສຳເລັດແລ້ວ."; // ຂໍ້ຄວາມສຳເລັດສໍາລັບການອັບເດດ.

            $data2=""; // ຕົວແປສໍາລັບຄໍາສັ່ງ SQL ຂອງ keyword_list.
            foreach($kw_arr as $kw){ // ວົນລູບຜ່ານຄໍາຫຼັກ.
                if(!empty($data2)) $data2 .= ", "; // ເພີ່ມ comma.
                $data2 .= "('{$rid}', '{$kw}')"; // ສ້າງຄູ່ (response_id, keyword).
            }

            // ລຶບຄໍາຫຼັກເກົ່າທີ່ກ່ຽວຂ້ອງກັບ response_id ນີ້ກ່ອນ.
            $this->conn->query("DELETE FROM `keyword_list` where response_id = '{$rid}'");
            $sql2 = "INSERT INTO `keyword_list` (`response_id`, `keyword`) VALUES {$data2}"; // ສ້າງຄໍາສັ່ງ INSERT.
            $save2 = $this->conn->query($sql2); // ປະຕິບັດຄໍາສັ່ງ SQL.

            if(!$save2){ // ຖ້າການບັນທຶກ keyword ລົ້ມເຫຼວ.
                if(empty($id))
                // ຖ້າເປັນການສ້າງໃໝ່ ແລະບັນທຶກ keyword ລົ້ມເຫຼວ, ໃຫ້ລຶບ keyword ທີ່ອາດຈະຖືກເພີ່ມໄປແລ້ວ.
                $this->conn->query("DELETE FROM `keyword_list` where response_id = '{$rid}'");
                $resp['status'] = 'failed'; // ຕັ້ງສະຖານະເປັນ 'failed'.
                $resp['msg'] = $this->conn->error; // ເກັບຂໍ້ຜິດພາດ.
                $resp['sql'] = $sql2; // ເກັບຄໍາສັ່ງ SQL (ສໍາລັບ debug).
            }

            $data3=""; // ຕົວແປສໍາລັບຄໍາສັ່ງ SQL ຂອງ suggestion_list.
            $this->conn->query("DELETE FROM `suggestion_list` where response_id = '{$rid}'"); // ລຶບຄໍາແນະນໍາເກົ່າ.
            foreach($suggestion as $sg){ // ວົນລູບຜ່ານຄໍາແນະນໍາ.
                if(empty($sg))
                continue; // ຂ້າມຖ້າຄໍາແນະນໍາຫວ່າງເປົ່າ.
                $sg = $this->conn->real_escape_string($sg); // ປ້ອງກັນ SQL Injection.
                if(!empty($data3)) $data3 .= ", "; // ເພີ່ມ comma.
                $data3 .= "('{$rid}', '{$sg}')"; // ສ້າງຄູ່ (response_id, suggestion).
            }
            if(!empty($data3)){ // ຖ້າມີຄໍາແນະນໍາທີ່ຈະບັນທຶກ.
                $sql3 = "INSERT INTO `suggestion_list` (`response_id`, `suggestion`) VALUES {$data3}"; // ສ້າງຄໍາສັ່ງ INSERT.
                $save3 = $this->conn->query($sql3); // ປະຕິບັດຄໍາສັ່ງ SQL.
                if(!$save3){ // ຖ້າການບັນທຶກຄໍາແນະນໍາລົ້ມເຫຼວ.
                    if(empty($id))
                    // ຖ້າເປັນການສ້າງໃໝ່ ແລະບັນທຶກຄໍາແນະນໍາລົ້ມເຫຼວ, ໃຫ້ລຶບ keyword ທີ່ອາດຈະຖືກເພີ່ມໄປແລ້ວ.
                    $this->conn->query("DELETE FROM `keyword_list` where response_id = '{$rid}'");
                    $resp['status'] = 'failed'; // ຕັ້ງສະຖານະເປັນ 'failed'.
                    $resp['msg'] = $this->conn->error; // ເກັບຂໍ້ຜິດພາດ.
                    $resp['sql'] = $sql3; // ເກັບຄໍາສັ່ງ SQL (ສໍາລັບ debug).
                }
            }
        }else{ // ຖ້າການບັນທຶກ response_list ລົ້ມເຫຼວ.
            $resp['status'] = 'failed'; // ຕັ້ງສະຖານະເປັນ 'failed'.
            $resp['err'] = $this->conn->error."[{$sql}]"; // ເກັບຂໍ້ຜິດພາດແລະຄໍາສັ່ງ SQL.
        }
        if($resp['status'] == 'success')
            $this->settings->set_flashdata('success',$resp['msg']); // ຕັ້ງຄ່າ flashdata ສໍາລັບຂໍ້ຄວາມສຳເລັດ.
            return json_encode($resp); // ສົ່ງຄືນຜົນລັບໃນຮູບແບບ JSON.
    }

    // ຟັງຊັນສໍາລັບການລຶບຄໍາຕອບ.
    function delete_response(){
        extract($_POST); // ແຍກຂໍ້ມູນທີ່ສົ່ງມາຈາກ $_POST.
        $del = $this->conn->query("DELETE FROM `response_list` where id = '{$id}'"); // ລຶບຄໍາຕອບຈາກຖານຂໍ້ມູນ.
        if($del){ // ຖ້າການລຶບສຳເລັດ.
            $resp['status'] = 'success'; // ຕັ້ງສະຖານະເປັນ 'success'.
            $this->settings->set_flashdata('success',"ລຶບຄໍາຕອບສຳເລັດແລ້ວ."); // ຕັ້ງຄ່າ flashdata.
        }else{
            $resp['status'] = 'failed'; // ຖ້າລຶບບໍ່ສຳເລັດ.
            $resp['error'] = $this->conn->error; // ເກັບຂໍ້ຜິດພາດ.
        }
        return json_encode($resp); // ສົ່ງຄືນຜົນລັບໃນຮູບແບບ JSON.
    }

    // ຟັງຊັນສໍາລັບການດຶງຄໍາຕອບໂດຍອີງໃສ່ຄໍາຫຼັກ.
    function fetch_response(){
        extract($_POST); // ແຍກຂໍ້ມູນທີ່ສົ່ງມາຈາກ $_POST (ຄໍາຫຼັກ $kw).
        // ສ້າງຄໍາສັ່ງ SQL ເພື່ອດຶງຄໍາຕອບທີ່ມີຄໍາຫຼັກທີ່ກົງກັນ.
        $sql = "SELECT * FROM `response_list` where id in (SELECT response_id FROM `keyword_list` where `keyword` = '{$kw}')";
        $resp['sql'] = $sql; // ເກັບຄໍາສັ່ງ SQL (ສໍາລັບ debug).
        $qry = $this->conn->query($sql); // ປະຕິບັດຄໍາສັ່ງ SQL.

        if($qry){ // ຖ້າການສອບຖາມສຳເລັດ.
            if($qry->num_rows > 0){ // ຖ້າພົບຄໍາຕອບ.
                $result = $qry->fetch_array(); // ດຶງຂໍ້ມູນຄໍາຕອບ.
                $resp['status'] = 'success'; // ຕັ້ງສະຖານະເປັນ 'success'.
                $resp['response'] = $result['response']; // ເກັບຄໍາຕອບ.

                // ດຶງຄໍາແນະນໍາທີ່ກ່ຽວຂ້ອງກັບຄໍາຕອບນີ້.
                $sg_qry = $this->conn->query("SELECT suggestion from `suggestion_list` where response_id = '{$result['id']}'");
                if($sg_qry->num_rows > 0){ // ຖ້າມີຄໍາແນະນໍາສະເພາະສໍາລັບຄໍາຕອບນີ້.
                    $suggestions = array_column($sg_qry->fetch_all(MYSQLI_ASSOC), 'suggestion'); // ເກັບຄໍາແນະນໍາເປັນອາເຣ.
                }else{
                    // ຖ້າບໍ່ມີຄໍາແນະນໍາສະເພາະ, ໃຫ້ໃຊ້ຄໍາແນະນໍາທົ່ວໄປຈາກການຕັ້ງຄ່າລະບົບ.
                    $suggestions = $this->settings->info('suggestion') != "" ? json_decode($this->settings->info('suggestion')) : "";
                }
                $resp['suggestions'] = $suggestions; // ເກັບຄໍາແນະນໍາ.

                // ພະຍາຍາມກວດສອບ IP address ຂອງລູກຄ້າ.
                if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                    $client = $_SERVER['HTTP_CLIENT_IP'];
                } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                    $client = $_SERVER['HTTP_X_FORWARDED_FOR'];
                } else {
                    $client = $_SERVER['REMOTE_ADDR'];
                }
                // ບັນທຶກການຮ້ອງຂໍຄໍາຫຼັກເຂົ້າໃນຖານຂໍ້ມູນ (keyword_fetched).
                $this->conn->query("INSERT INTO `keyword_fetched` set `response_id` = '{$result['id']}', `client` = '{$client}'");
            }else{
                // ຖ້າບໍ່ພົບຄໍາຕອບໃດໆ, ໃຫ້ສົ່ງຄືນຂໍ້ຄວາມ "ບໍ່ມີຄໍາຕອບ".
                $resp['status'] = 'success';
                $resp['response'] = $this->settings->info('no_answer');
            }
        }else{
            $resp['status'] = "failed"; // ຖ້າການສອບຖາມລົ້ມເຫຼວ.
            $resp['msg'] = $this->conn->error; // ເກັບຂໍ້ຜິດພາດ.
        }
        return json_encode($resp); // ສົ່ງຄືນຜົນລັບໃນຮູບແບບ JSON.
    }
 }

 // ສ້າງ object ຂອງ Class Master.
 $Master = new Master();
 // ຕັ້ງຄ່າການກະທໍາໂດຍອີງໃສ່ຄ່າຂອງ $_GET['f'].
 $action = !isset($_GET['f']) ? 'none' : strtolower($_GET['f']);
 // ສ້າງ object ຂອງ SystemSettings (ເຖິງແມ່ນວ່າຈະບໍ່ໄດ້ໃຊ້ໂດຍກົງໃນ switch case ນີ້).
 $sysset = new SystemSettings();

 // ປະຕິບັດການກະທໍາທີ່ກໍານົດໄວ້.
 switch ($action) {
    case 'delete_img':
        echo $Master->delete_img(); // ເອີ້ນຟັງຊັນ delete_img.
    break;
    case 'save_response':
        echo $Master->save_response(); // ເອີ້ນຟັງຊັນ save_response.
    break;
    case 'delete_response':
        echo $Master->delete_response(); // ເອີ້ນຟັງຊັນ delete_response.
    break;
    case 'fetch_response':
        echo $Master->fetch_response(); // ເອີ້ນຟັງຊັນ fetch_response.
    break;
    default:
        // echo $sysset->index(); // ຖືກຄອມເມັ້ນໄວ້, ອາດຈະເປັນການສະແດງໜ້າຫຼັກຂອງລະບົບການຕັ້ງຄ່າ.
        break;
 }
 ?>